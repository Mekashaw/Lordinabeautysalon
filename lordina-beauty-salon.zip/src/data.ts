import { SalonService, Servant, Booking } from './types';

export const INITIAL_SERVICES: SalonService[] = [
  {
    id: 's1',
    nameEn: 'Sleek Silk Press & Styling',
    nameAm: 'የፀጉር ኬሚካል ማስተካከልና እስታይሊንግ',
    category: 'Hair',
    basePrice: 1200,
    descriptionEn: 'Deep wash, nourishing hair masque treatment, sleek flat-iron, and styling.',
    descriptionAm: 'ጥልቅ እጥበት፣ አልሚ የፀጉር ማስክ ሕክምና፣ ውብ የማስተካከልና እስታይሊንግ ሥራ።',
    durationMin: 45
  },
  {
    id: 's2',
    nameEn: 'Brazilian Keratin Blowout',
    nameAm: 'የብራዚሊያን ኬራቲን ህክምና',
    category: 'Hair',
    basePrice: 4500,
    descriptionEn: 'Premium damage-repair smoothing Treatment resulting in silky, freeze-free beautiful hair.',
    descriptionAm: 'ለረጅም ጊዜ የሚቆይ ፀጉርን ያለ ማቃጠል የሚያለሰልስና የሚጠግን ሕክምና።',
    durationMin: 120
  },
  {
    id: 's3',
    nameEn: 'Glamour Party Makeup',
    nameAm: 'የፓርቲ ግላመር ሜካፕ',
    category: 'Makeup',
    basePrice: 2500,
    descriptionEn: 'Full flawless airbrush makeup, gorgeous lash install, highlight and contouring.',
    descriptionAm: 'ሙሉ የፊት ሜካፕ፣ የዐይን ሽፋሽፍት መግጠም፣ ምርጥ ሃይላይቲንግና ኮንቱርን ጨምሮ።',
    durationMin: 50
  },
  {
    id: 's4',
    nameEn: 'Royal Caviar Facial Glow',
    nameAm: 'የካቪያር ሮያል የፊት ህክምና',
    category: 'Makeup',
    basePrice: 3200,
    descriptionEn: 'Luxury collagen replenishment, gold charcoal scrub, organic hydrating mask and LED treatment.',
    descriptionAm: 'የፊት ቆዳን የሚያድስ ኮላጅን፣ የወርቅ ቻርኮል ስክረብ፣ ለስላሳ ማስክና የብርሃን ህክምና።',
    durationMin: 60
  },
  {
    id: 's5',
    nameEn: 'Gel Extension Nail Art & Spa',
    nameAm: 'የጄል ጥፍር ቅጥያ እና የጥፍር ስነ-ውበት',
    category: 'Nails',
    basePrice: 1500,
    descriptionEn: 'Full set custom gel extensions, modern hand-painted nail designs, and nourishing tea-tree oil rub.',
    descriptionAm: 'ሙሉ የጄል ጥፍር ስራ ከፈጠራ ስዕሎችና ጥፍርን ከሚያጠነክሩ የተፈጥሮ ዘይቶች ጋር።',
    durationMin: 75
  },
  {
    id: 's6',
    nameEn: 'Premium Pedicure & Feet Rejuvenation',
    nameAm: 'የእግር ፔዲኪዩር እና ማሳጅ',
    category: 'Nails',
    basePrice: 1200,
    descriptionEn: 'Dead skin rasping, sea salt feet aromatherapy bath, scrub, paraffin moisture wrap, and massage.',
    descriptionAm: 'የእግር ማጽዳት፣ በባህር ጨው የሚደረግ የእንፋሎት መታጠብ፣ ስክረብና የእግር ማሳጅ።',
    durationMin: 60
  },
  {
    id: 's7',
    nameEn: 'Hot Stone & Aromatherapy Body Massage',
    nameAm: 'የሙቅ ድንጋይና የአሮማቴራፒ አጠቃላይ ማሳጅ',
    category: 'Spa',
    basePrice: 3000,
    descriptionEn: 'Heated basalt stones with therapeutic essential oils to fully release muscle tension and deep stress.',
    descriptionAm: 'በልዩ ሙቅ የባሳልት ድንጋዮችና የተፈጥሮ መዓዛ ዘይቶች የሚሰራ ውጥረትን የሚያስወግድ ማሳጅ።',
    durationMin: 90
  },
  {
    id: 's8',
    nameEn: 'Lordina Royal Bridal Empress Package',
    nameAm: 'የሎርዲና ሮያል የሙሽሮች ሙሉ ፓኬጅ',
    category: 'VIP Packages',
    basePrice: 15000,
    descriptionEn: 'The Ultimate Royal bridal hair trial + actual day, complete luxury makeup, deluxe spa treatment, manicure/pedicure.',
    descriptionAm: 'የሙሽሮች ፀጉር ዲዛይን፣ ሙከራን ጨምሮ፣ ሙሉ ዘመናዊ ሜካፕ፣ የጥፍርና የሰውነት ማሳጅ ህክምና።',
    durationMin: 240
  }
];

export const INITIAL_SERVANTS: Servant[] = [
  {
    id: 'v1',
    name: 'Lordina Kassa',
    nameAm: 'ሎርዲና ካሳ',
    roleEn: 'Founder & Master Stylist',
    roleAm: 'መስራች እና ዋና ከፍተኛ ባለሙያ',
    rating: 4.9,
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200',
    specialtiesEn: ['Bridal Updos', 'Keratin Treatments', 'VVIP Styling'],
    specialtiesAm: ['የሙሽሮች ፀጉር', 'ኬራቲን ህክምና', 'ቪቪአይፒ ዲዛይኖች'],
    status: 'Active'
  },
  {
    id: 'v2',
    name: 'Selam Mengistu',
    nameAm: 'ሰላም መንግስቱ',
    roleEn: 'Hair Artistry & Extension Specialist',
    roleAm: 'የፀጉር ጥበብና ቅጥያ ባለሙያ',
    rating: 4.8,
    avatar: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&q=80&w=200',
    specialtiesEn: ['Tape-Ins & Braids', 'Sleek Silk Press', 'Custom Hair Dye'],
    specialtiesAm: ['የፀጉር ቅጥያና ጉንጉን', 'ሲልክ ፕሬስ', 'የፀጉር ቀለም መቀየር'],
    status: 'Active'
  },
  {
    id: 'v3',
    name: 'Betelhem Girma',
    nameAm: 'ቤተልሔም ግርማ',
    roleEn: 'Senior makeup Artist',
    roleAm: 'ከፍተኛ የፊት ውበትና ሜካፕ ባለሙያ',
    rating: 4.7,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
    specialtiesEn: ['Glam Makeup', 'Airbrush Cosmetics', 'Eyelashes'],
    specialtiesAm: ['ግላም ሜካፕ', 'ኤርብረሽ ኮስሜቲክስ', 'የዐይን ሽፋሽፍት'],
    status: 'Active'
  },
  {
    id: 'v4',
    name: 'Eden Tadesse',
    nameAm: 'ኤደን ታደሰ',
    roleEn: 'Nails & Aesthetics Guru',
    roleAm: 'የጥፍር ቅጥያና ዲዛይን ባለሙያ',
    rating: 4.8,
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200',
    specialtiesEn: ['Gel Extensions', 'French Nail Art', 'Pedicure Spa'],
    specialtiesAm: ['ጄል ጥፍር ስራ', 'ፍሬንች ጥፍር አርት', 'የእግር ፔዲኪዩር'],
    status: 'Active'
  },
  {
    id: 'v5',
    name: 'Tigist Bekele',
    nameAm: 'ትዕግሥት በቀለ',
    roleEn: 'Massage & Facial Spa Specialist',
    roleAm: 'የሰውነት ማሳጅና የቆዳ እንክብካቤ ባለሙያ',
    rating: 4.6,
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=200',
    specialtiesEn: ['Hot Stone Therapy', 'Hydration Facials', 'Aromatherapy'],
    specialtiesAm: ['የሙቅ ድንጋይ ማሳጅ', 'የፊት ቆዳ ህክምና', 'የመዓዛ ዘይት ህክምና'],
    status: 'Active'
  }
];

export const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'b1',
    customerName: 'Melat Yoseph',
    customerPhone: '0911223344',
    serviceId: 's3',
    servantId: 'v3',
    timeSlot: '09:00 AM',
    tier: 'VIP',
    paidAmount: 3750, // 2500 + 50%
    paidStatus: 'Paid',
    paymentMethod: 'Telebirr',
    queueNo: 101,
    status: 'Serving',
    createdAt: new Date().toISOString(),
    date: '2026-06-18'
  },
  {
    id: 'b2',
    customerName: 'Tsion Abraham',
    customerPhone: '0922445566',
    serviceId: 's1',
    servantId: 'v2',
    timeSlot: '10:00 AM',
    tier: 'Normal',
    paidAmount: 1200,
    paidStatus: 'Paid',
    paymentMethod: 'CBE Birr',
    queueNo: 102,
    status: 'Serving',
    createdAt: new Date().toISOString(),
    date: '2026-06-18'
  },
  {
    id: 'b3',
    customerName: 'Rahel Desta',
    customerPhone: '0910908070',
    serviceId: 's8',
    servantId: 'v1',
    timeSlot: '10:30 AM',
    tier: 'VVIP',
    paidAmount: 30000, // 15000 + 100%
    paidStatus: 'Paid',
    paymentMethod: 'Chapa (Card)',
    queueNo: 103,
    status: 'Waiting',
    createdAt: new Date().toISOString(),
    date: '2026-06-18'
  },
  {
    id: 'b4',
    customerName: 'Helen Berhe',
    customerPhone: '0912345678',
    serviceId: 's5',
    servantId: 'v4',
    timeSlot: '11:00 AM',
    tier: 'Normal',
    paidAmount: 1500,
    paidStatus: 'Paid',
    paymentMethod: 'Telebirr',
    queueNo: 104,
    status: 'Waiting',
    createdAt: new Date().toISOString(),
    date: '2026-06-18'
  },
  {
    id: 'b5',
    customerName: 'Samrawit Kifle',
    customerPhone: '0944001122',
    serviceId: 's6',
    servantId: 'v4',
    timeSlot: '01:30 PM',
    tier: 'VIP',
    paidAmount: 1800, // 1200 + 50%
    paidStatus: 'Paid',
    paymentMethod: 'Telebirr',
    queueNo: 105,
    status: 'Waiting',
    createdAt: new Date().toISOString(),
    date: '2026-06-18'
  }
];

export const TIMEOBJECTS = [
  '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
  '12:00 PM', '12:30 PM', '01:00 PM', '01:30 PM', '02:00 PM', '02:30 PM',
  '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM', '05:00 PM', '05:35 PM',
  '06:00 PM', '06:30 PM', '07:00 PM', '07:30 PM'
];
