import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "gen-lang-client-0864058528",
  appId: "1:1016865283645:web:4fc31b990cd40b2d2c9454",
  apiKey: "AIzaSyCvVm4IGkXW_jKku-2yeCArmD7PTb4TyQc",
  authDomain: "gen-lang-client-0864058528.firebaseapp.com",
  databaseId: "ai-studio-91fb0cf5-8bac-46b5-8c32-a56d1ca5fa0b",
  storageBucket: "gen-lang-client-0864058528.firebasestorage.app",
  messagingSenderId: "1016865283645"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Cloud Firestore and get a reference to the service
export const db = getFirestore(app);
