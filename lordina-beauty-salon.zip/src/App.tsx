/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import BookingWizard from './components/BookingWizard';
import QueueBoard from './components/QueueBoard';
import ServantSchedules from './components/ServantSchedules';
import AdminPanel from './components/AdminPanel';
import LoginModal from './components/LoginModal';
import { translations } from './translations';
import { INITIAL_SERVICES, INITIAL_SERVANTS, INITIAL_BOOKINGS } from './data';
import { SalonService, Servant, Booking } from './types';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Calendar, Users, Clock, Settings, 
  MapPin, PhoneCall, Heart, Quote, Instagram, Facebook, Star,
  MessageCircle, Send, X, HelpCircle
} from 'lucide-react';
import { db } from './firebase';
import { collection, doc, setDoc, updateDoc, onSnapshot, writeBatch } from 'firebase/firestore';

export default function App() {
  const [currentLang, setCurrentLang] = useState<'en' | 'am'>('am');
  
  // App-wide data states (automatically synchronized with Firestore)
  const [services] = useState<SalonService[]>(INITIAL_SERVICES);
  const [servants, setServants] = useState<Servant[]>(INITIAL_SERVANTS);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);

  // User Auth status
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(() => {
    return localStorage.getItem('lordina_is_logged_in') === 'true';
  });
  const [username, setUsername] = useState<string | null>(() => {
    return localStorage.getItem('lordina_username');
  });
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem('lordina_is_admin') === 'true';
  });

  // UI Dialog states
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'book' | 'queue' | 'schedule' | 'admin'>('book');

  // Public Announcement / Control Notice State
  const [publicNotice, setPublicNotice] = useState(() => {
    return {
      enabled: true,
      titleAm: 'በጎንደር ቅርንጫፍ ታላቅ ቅናሽ!',
      titleEn: 'Grand Opening Sale in Gonder!',
      messageAm: 'የጎንደር ቅርንጫፍ መከፈትን አስመልክቶ ለሚቀጥሉት 2 ሳምንታት ለሁሉም የፀጉር ኬራቲን እና የጥፍር አገልግሎቶች 15% ቅናሽ አድርገናል። ቀድመው ቀጠሮ ይያዙ!',
      messageEn: 'To celebrate our new Gonder branch opening, we are offering a 15% discount on all Hair Keratin & Nail services for the next 2 weeks. Book your spot now!',
      badgeAm: 'ልዩ ቅናሽ',
      badgeEn: 'SPECIAL PROMO',
      type: 'promo' as 'promo' | 'info' | 'alert'
    };
  });

  const [dismissedNotice, setDismissedNotice] = useState(false);

  // Floating Assistant Chat States
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [chatMessages, setChatMessages] = useState<{sender: 'user' | 'bot'; text: string; time: string}[]>(() => [
    {
      sender: 'bot',
      text: 'ሰላም! ሎርዲና የሴቶች የውበት ሳሎን እራስጌ ረዳት እንኳን ደህና መጡ። 💅✨ እንዴት ልረዳዎት እችላለሁ?\n\nHello! Welcome to Lordina Girls Beauty Salon virtual support helper. How may I assist you today?',
      time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
    }
  ]);
  const [typedMessage, setTypedMessage] = useState('');

  const sendChatMessage = (text: string) => {
    if (!text.trim()) return;

    const timestamp = new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    const newUserMsg = { sender: 'user' as const, text, time: timestamp };
    setChatMessages(prev => [...prev, newUserMsg]);
    setIsTyping(true);

    setTimeout(() => {
      let reply = '';
      const query = text.toLowerCase();
      
      if (query.includes('book') || query.includes('ማስያዝ') || query.includes('አያያዝ') || query.includes('አሰራር')) {
        reply = currentLang === 'am' 
          ? 'ለመመዝገብ ከላይ ሰማያዊ/ሮዝ ያለውን "የቀጠሮ አገልግሎቶች" ክፍል ይምረጡ። ስም፣ ስልክ ቁጥር ካስገቡ በኋላ በቴሌብር፣ በንግድ ባንክ ወይም በዳሽን ባንክ የተከፈለበትን ደረሰኝ ስክሪንሾት በማያያዝ "ወረፋ ያዙ" የሚለውን ይጫኑ። 💖'
          : 'To reserve a slot, go to the booking wizard, select a service, a stylist, enter your name and phone, transfer the secure payment on Telebirr/CBE/Dashen/Abyssinia copyable accounts, upload the receipt screenshot and click Book! 💖';
      } else if (query.includes('ሰዓት') || query.includes('hour') || query.includes('time') || query.includes('መቼ')) {
        reply = currentLang === 'am' 
          ? 'የሳሎናችን የሥራ ሰዓታት ከሰኞ እስከ ቅዳሜ ከጠዋቱ 3:00 ሰዓት እስከ ማታ 2:30 ሰዓት ነው። እሁድ ዝግ ነን። 📅✨'
          : 'Our salon is open Monday to Saturday from 09:00 AM to 08:30 PM. We are closed on Sundays. 📅✨';
      } else if (query.includes('ስልክ') || query.includes('phone') || query.includes('call') || query.includes('ቁጥር')) {
        reply = currentLang === 'am' 
          ? 'በቀጥታ በስልክ ቁጥራችን +251 900 123 456 በመደወል የደንበኞች ቀጥታ ድጋፍ ማግኘት ይችላሉ! 📞🌸'
          : 'You can directly dial our helpline at +251 900 123 456 for instant phone support! 📞🌸';
      } else if (query.includes('ዋጋ') || query.includes('ብር') || query.includes('price') || query.includes('cost')) {
        reply = currentLang === 'am' 
          ? 'የአገልግሎቶቻችን ዋጋ እንደየምርጫዎ ይለያያል። ኖርማል፣ VIP እና Royal የተባሉ ሦስት ደረጃዎች አሉን። ሁሉንም ዝርዝር ዋጋዎች በ"የቀጠሮ አገልግሎቶች" ሰንጠረዥ ላይ ማግኘት ይችላሉ! 💅💰'
          : 'We have three levels of service tiers: Normal, VIP, and Royal. You can view all pricing breakdowns clearly inside the booking wizard selector! 💅💰';
      } else {
        reply = currentLang === 'am' 
          ? 'መልእክትዎ ደርሶናል። ባለሙያዎቻችን በአጭር ጊዜ ውስጥ በስልክ ቁጥርዎ ያነጋግሩዎታል። ሎርዲናን ስለመረጡ እናመሰግናለን! 🙏🌸'
          : 'We have received your request! A Lordina Salon specialist will contact you shortly to confirm your booking. Thank you for choosing us! 🙏🌸';
      }

      setChatMessages(prev => [...prev, {
        sender: 'bot' as const,
        text: reply,
        time: new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})
      }]);
      setIsTyping(false);
    }, 1000);
  };

  // Synchronize Firestore Data Real-time on component mount
  useEffect(() => {
    // 1. Subscribe/Sync Bookings
    const unsubscribeBookings = onSnapshot(collection(db, 'bookings'), async (snapshot) => {
      if (snapshot.empty) {
        // Seed initial bookings if Firestore is completely empty (first run)
        try {
          const batch = writeBatch(db);
          INITIAL_BOOKINGS.forEach((b) => {
            const docRef = doc(db, 'bookings', b.id);
            batch.set(docRef, b);
          });
          await batch.commit();
        } catch (err) {
          console.error("Error seeding initial bookings:", err);
        }
        setBookings(INITIAL_BOOKINGS);
      } else {
        const loadedBookings: Booking[] = [];
        snapshot.forEach((docSnap) => {
          loadedBookings.push(docSnap.data() as Booking);
        });
        // Sort bookings by priority/createdAt: newer bookings first, keeping layout clean
        loadedBookings.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setBookings(loadedBookings);
      }
    }, (error) => {
      console.error("Firestore booking subscription error:", error);
    });

    // 2. Subscribe/Sync Servants
    const unsubscribeServants = onSnapshot(collection(db, 'servants'), async (snapshot) => {
      if (snapshot.empty) {
        // Seed initial servants list if Firestore is empty
        try {
          const batch = writeBatch(db);
          INITIAL_SERVANTS.forEach((s) => {
            const docRef = doc(db, 'servants', s.id);
            batch.set(docRef, s);
          });
          await batch.commit();
        } catch (err) {
          console.error("Error seeding initial servants:", err);
        }
        setServants(INITIAL_SERVANTS);
      } else {
        const loadedServants: Servant[] = [];
        snapshot.forEach((docSnap) => {
          loadedServants.push(docSnap.data() as Servant);
        });
        // Keep order consistent alphabetically or by original data order matching ratings & specialties
        loadedServants.sort((a, b) => a.id.localeCompare(b.id));
        setServants(loadedServants);
      }
    }, (error) => {
      console.error("Firestore servant subscription error:", error);
    });

    // 3. Subscribe/Sync Public Notice Config Info
    const unsubscribeNotice = onSnapshot(doc(db, 'config', 'public_notice'), (docSnap) => {
      if (docSnap.exists()) {
        setPublicNotice(docSnap.data() as any);
      } else {
        // Create the fallback promo notice document inside Firestore
        const fallbackNotice = {
          enabled: true,
          titleAm: 'በጎንደር ቅርንጫፍ ታላቅ ቅናሽ!',
          titleEn: 'Grand Opening Sale in Gonder!',
          messageAm: 'የጎንደር ቅርንጫፍ መከፈትን አስመልክቶ ለሚቀጥሉት 2 ሳምንታት ለሁሉም የፀጉር ኬራቲን እና የጥፍር አገልግሎቶች 15% ቅናሽ አድርገናል። ቀድመው ቀጠሮ ይያዙ!',
          messageEn: 'To celebrate our new Gonder branch opening, we are offering a 15% discount on all Hair Keratin & Nail services for the next 2 weeks. Book your spot now!',
          badgeAm: 'ልዩ ቅናሽ',
          badgeEn: 'SPECIAL PROMO',
          type: 'promo'
        };
        setDoc(doc(db, 'config', 'public_notice'), fallbackNotice).catch(err => console.error("Error creating notice doc:", err));
        setPublicNotice(fallbackNotice);
      }
    }, (error) => {
      console.error("Firestore public notice subscription error:", error);
    });

    return () => {
      unsubscribeBookings();
      unsubscribeServants();
      unsubscribeNotice();
    };
  }, []);

  // Auth synchronization
  const handleLoginSuccess = (user: string, adminRole: boolean) => {
    setIsLoggedIn(true);
    setUsername(user);
    setIsAdmin(adminRole);
    localStorage.setItem('lordina_is_logged_in', 'true');
    localStorage.setItem('lordina_username', user);
    localStorage.setItem('lordina_is_admin', adminRole ? 'true' : 'false');
    
    // Auto shift tab if Admin login
    if (adminRole) {
      setActiveTab('admin');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername(null);
    setIsAdmin(false);
    localStorage.removeItem('lordina_is_logged_in');
    localStorage.removeItem('lordina_username');
    localStorage.removeItem('lordina_is_admin');
    setActiveTab('book');
  };

  // State mutators (passed to sub-widgets)
  const handleNewBooking = async (booking: Booking) => {
    try {
      await setDoc(doc(db, 'bookings', booking.id), booking);
    } catch (err) {
      console.error("Error creating booking document on Firestore:", err);
      // Local fallback
      setBookings(prev => [booking, ...prev]);
    }
  };

  const handleUpdateBookingStatus = async (id: string, state: 'Waiting' | 'Serving' | 'Completed' | 'Cancelled') => {
    try {
      await updateDoc(doc(db, 'bookings', id), { status: state });
    } catch (err) {
      console.error("Error updating booking status on Firestore:", err);
      // Local fallback
      setBookings(prev => prev.map(b => b.id === id ? { ...b, status: state } : b));
    }
  };

  const handleUpdateServantStatus = async (id: string, shiftState: 'Active' | 'On Break' | 'Day Off') => {
    try {
      await updateDoc(doc(db, 'servants', id), { status: shiftState });
    } catch (err) {
      console.error("Error updating servant status on Firestore:", err);
      // Local fallback
      setServants(prev => prev.map(s => s.id === id ? { ...s, status: shiftState } : s));
    }
  };

  const handleUpdatePublicNotice = async (notice: any) => {
    try {
      await setDoc(doc(db, 'config', 'public_notice'), notice);
    } catch (err) {
      console.error("Error setting public notice on Firestore:", err);
      setPublicNotice(notice);
    }
  };

  // Retrieve user's own ticket if logged in as regular client
  const userTicket = bookings.find(b => 
    b.customerPhone === username && 
    (b.status === 'Waiting' || b.status === 'Serving')
  );

  return (
    <div className="min-h-screen bg-[#fff1f2] text-[#881337] font-sans selection:bg-rose-200 selection:text-rose-950 flex flex-col justify-between">
      
      {/* Header component */}
      <Header 
        currentLang={currentLang}
        setCurrentLang={setCurrentLang}
        isLoggedIn={isLoggedIn}
        username={username}
        isAdmin={isAdmin}
        onOpenLogin={() => setIsLoginOpen(true)}
        onLogout={handleLogout}
      />

      {/* HERO SECTION - Gilded Rose Blush styling */}
      <section className="relative overflow-hidden py-10 sm:py-16 text-center px-4 bg-gradient-to-r from-rose-100/50 via-rose-100 to-pink-50/40 border-b border-rose-100">
        {/* Abstract absolute background graphics */}
        <div className="absolute top-0 left-0 w-32 h-32 bg-pink-300 rounded-full filter blur-[100px] opacity-35"></div>
        <div className="absolute bottom-0 right-0 w-48 h-48 bg-rose-300 rounded-full filter blur-[120px] opacity-35"></div>
        
        <div className="max-w-4xl mx-auto space-y-4">
          
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white text-rose-700 border border-rose-200 rounded-full text-xs font-black tracking-wide animate-bounce">
            <Heart className="w-3.5 h-3.5 fill-pink-500 text-pink-500" />
            <span>{currentLang === 'en' ? 'GONDER PREMIER BEAUTY SALON' : 'የጎንደር ምርጥ የሴቶች ሳሎን'}</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-rose-950 tracking-tight leading-none uppercase">
            {currentLang === 'en' ? 'Define Your Gorgeous Look' : 'ውበትዎን በእኛ ባለሙያዎች ያድምቁ'}
          </h2>
          
          <p className="text-sm sm:text-lg text-rose-900 font-medium max-w-2xl mx-auto leading-relaxed">
            {currentLang === 'en'
              ? 'Lordina Girls Beauty Salon introduces bespoke cosmetics, rich natural keratin blowouts, state-of-the-art extensions, and absolute privacy.'
              : 'ሎርዲና የሴቶች የውበት ሳሎን ዘመናዊ መዋቢያዎችን፣ ምርጥ ኬራቲን ፀጉር ህክምናዎችን፣ የጥፍር ውበት ስራዎችን እንዲሁም ሙሉ ጥበቃ ያላቸውን አገልግሎቶች ያቀርብሎታል።'}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-rose-800 pt-2 pb-1">
            <span className="flex items-center gap-1.5 bg-white/85 px-4 py-1.5 rounded-full border border-rose-200/60 shadow-sm">
              <Clock className="w-4 h-4 text-rose-500 animate-pulse" /> 
              {currentLang === 'en' ? '09:00 AM - 08:30 PM (Mon-Sat)' : 'ከሰኞ - ቅዳሜ ከጠዋቱ 3:00 - ማታ 2:30'}
            </span>
          </div>

        </div>
      </section>

      {/* USER ACTIVE PASS NOTIFIER BAR (If logged in and has an active ticket) */}
      {isLoggedIn && userTicket && (
        <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 pt-6">
          <div className="bg-pink-600 rounded-2xl p-4 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-md animate-pulse">
            <div>
              <p className="text-xs uppercase font-extrabold tracking-widest text-pink-100">
                {translations.yourActiveBooking[currentLang]}
              </p>
              <h5 className="font-bold text-sm sm:text-base">
                🎟 Ticket <span className="font-mono bg-pink-700 px-2 py-0.5 rounded text-xs">{userTicket.id}</span> is actively listed in queue position <strong className="text-white">#{userTicket.queueNo}</strong> with <strong className="text-rose-100">{services.find(s => s.id === userTicket.serviceId)?.nameEn}</strong>.
              </h5>
            </div>
            
            <button
              onClick={() => setActiveTab('queue')}
              className="px-4 py-2 bg-white text-pink-700 hover:bg-rose-50 text-xs font-black rounded-xl shadow-sm transition-all cursor-pointer"
            >
              {currentLang === 'en' ? 'Track Live Board' : 'የቀጥታ ሰሌዳ ተከታተል'}
            </button>
          </div>
        </div>
      )}

      {/* NAVIGATION TABS SELECTORS */}
      <main className="max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-6 flex-1">
        
        {/* Navigation Tabs bar */}
        <div className="flex border-b border-rose-100 max-w-2xl mx-auto justify-center gap-1.5 sm:gap-4 pb-1">
          <button
            onClick={() => setActiveTab('book')}
            className={`pb-3 px-3 relative text-xs sm:text-sm font-bold tracking-tight transition-all cursor-pointer ${
              activeTab === 'book' ? 'text-rose-600 font-extrabold' : 'text-rose-800 hover:text-rose-500'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4" />
              {translations.bookingTab[currentLang]}
            </span>
            {activeTab === 'book' && (
              <motion.div layoutId="activeNavIndicator" className="absolute bottom-0 left-0 w-full h-0.5 bg-rose-500 rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('queue')}
            className={`pb-3 px-3 relative text-xs sm:text-sm font-bold tracking-tight transition-all cursor-pointer ${
              activeTab === 'queue' ? 'text-rose-600 font-extrabold' : 'text-rose-800 hover:text-rose-500'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Users className="w-4 h-4" />
              {translations.queueTab[currentLang]}
            </span>
            {activeTab === 'queue' && (
              <motion.div layoutId="activeNavIndicator" className="absolute bottom-0 left-0 w-full h-0.5 bg-rose-500 rounded-full" />
            )}
          </button>

          <button
            onClick={() => setActiveTab('schedule')}
            className={`pb-3 px-3 relative text-xs sm:text-sm font-bold tracking-tight transition-all cursor-pointer ${
              activeTab === 'schedule' ? 'text-rose-600 font-extrabold' : 'text-rose-800 hover:text-rose-500'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              {translations.scheduleTab[currentLang]}
            </span>
            {activeTab === 'schedule' && (
              <motion.div layoutId="activeNavIndicator" className="absolute bottom-0 left-0 w-full h-0.5 bg-rose-500 rounded-full" />
            )}
          </button>

          {/* Admin Dashboard Tab (visible to all but locked with a beautiful login prompt representation if not admin) */}
          <button
            onClick={() => setActiveTab('admin')}
            className={`pb-3 px-3 relative text-xs sm:text-sm font-bold tracking-tight transition-all cursor-pointer ${
              activeTab === 'admin' ? 'text-rose-600 font-extrabold' : 'text-rose-800 hover:text-rose-500'
            }`}
          >
            <span className="flex items-center gap-1.5">
              <Settings className="w-4 h-4" />
              {translations.adminTab[currentLang]}
            </span>
            {activeTab === 'admin' && (
              <motion.div layoutId="activeNavIndicator" className="absolute bottom-0 left-0 w-full h-0.5 bg-rose-500 rounded-full" />
            )}
          </button>
        </div>

        {/* PUBLIC CONTROL ANNOUNCEMENT NOTICE POST */}
        {publicNotice.enabled && !dismissedNotice && (
          <div className={`p-4 sm:p-5 rounded-3xl border text-left relative overflow-hidden transition-all duration-300 shadow-sm max-w-4xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
            publicNotice.type === 'promo' 
              ? 'bg-gradient-to-r from-pink-500/10 via-rose-500/5 to-white border-rose-200/60 text-rose-950' 
              : publicNotice.type === 'alert'
              ? 'bg-gradient-to-r from-amber-500/10 via-amber-500/5 to-white border-amber-200/60 text-amber-950'
              : 'bg-gradient-to-r from-blue-500/10 via-blue-500/5 to-white border-blue-200/60 text-blue-950'
          }`}>
            <div className="flex items-start gap-3 flex-1">
              <span className="text-2xl mt-0.5 select-none shrink-0">
                {publicNotice.type === 'promo' ? '💝' : publicNotice.type === 'alert' ? '⚠️' : '📢'}
              </span>
              <div>
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className={`text-[9px] uppercase font-bold tracking-widest px-2 py-0.5 rounded-full ${
                    publicNotice.type === 'promo'
                      ? 'bg-rose-500 text-white'
                      : publicNotice.type === 'alert'
                      ? 'bg-amber-600 text-white'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {currentLang === 'en' ? publicNotice.badgeEn : publicNotice.badgeAm}
                  </span>
                  <h4 className="text-xs sm:text-sm font-black uppercase tracking-tight font-sans">
                    {currentLang === 'en' ? publicNotice.titleEn : publicNotice.titleAm}
                  </h4>
                </div>
                <p className="text-xs font-semibold leading-relaxed text-neutral-700 mt-1 max-w-3xl">
                  {currentLang === 'en' ? publicNotice.messageEn : publicNotice.messageAm}
                </p>
              </div>
            </div>

            <button
              onClick={() => setDismissedNotice(true)}
              className="px-2.5 py-1 text-[10px] sm:text-xs font-bold text-neutral-400 hover:text-neutral-600 cursor-pointer hover:bg-neutral-100 rounded-lg transition-all shrink-0 self-end sm:self-center"
              title="Dismiss Announcement"
            >
              {currentLang === 'en' ? 'Dismiss' : 'ደብቅ'}
            </button>
          </div>
        )}

        {/* ACTIVE MODULE CONTAINER with smooth transitions */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.2 }}
            className="w-full"
          >
            {/* 1. BOOK AND PAY MODULE */}
            {activeTab === 'book' && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                
                {/* Main Wizard */}
                <div className="lg:col-span-8">
                  <BookingWizard 
                    currentLang={currentLang}
                    services={services}
                    servants={servants}
                    bookings={bookings}
                    isLoggedIn={isLoggedIn}
                    loggedInName={username}
                    onNewBooking={handleNewBooking}
                  />
                </div>

                {/* Right Aesthetic Sidebar content */}
                <div className="lg:col-span-4 space-y-6">
                  
                  {/* Testimonial Quote */}
                  <div className="bg-gradient-to-br from-pink-50 to-rose-50/50 p-6 rounded-3xl border border-rose-100 text-left relative overflow-hidden">
                    <Quote className="absolute -top-3 -left-3 w-16 h-16 text-pink-200/50 fill-pink-100/50 -rotate-12" />
                    <div className="relative">
                      <div className="flex gap-0.5 mb-2.5">
                        {[1, 2, 3, 4, 5].map(star => <Star key={star} className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />)}
                      </div>
                      <p className="text-xs italic text-rose-950 font-medium leading-relaxed">
                        {currentLang === 'en' 
                          ? '"Absolutely incredible service at Lordina beauty salon! The VVIP hair press and organic facial are unrivaled in Gonder. Extremely pristine styling!"'
                          : '"በሎርዲና የሴቶች ሳሎን ያገኘሁት አገልግሎት እጅግ በጣም አስደናቂ ነበር! የቪቪአይፒ የፀጉር አሰራርና የፊት ህክምና በመላው ጎንደር አቻ የለውም!"'}
                      </p>
                      <span className="block text-[10px] font-extrabold text-pink-600 uppercase tracking-widest mt-3.5">— Hermela S. (Client since 2025)</span>
                    </div>
                  </div>

                  {/* Highlights Card list */}
                  <div className="p-6 bg-white rounded-3xl border border-rose-100 shadow-sm text-left space-y-4">
                    <h5 className="text-xs font-black text-rose-950 uppercase tracking-widest border-b border-rose-50 pb-2">
                      {currentLang === 'en' ? 'Our Brand Commitments' : 'የእኛ ልዩ አገልግሎቶች'}
                    </h5>

                    <ul className="space-y-3.5 text-xs text-rose-900 font-medium">
                      <li className="flex gap-2.5 items-start">
                        <span className="font-mono text-base text-pink-500 mt-0.5">👑</span>
                        <div>
                          <strong className="text-rose-950 block">Tailored VIP & VVIP Suites</strong>
                          <span className="text-[10px] text-neutral-600 leading-normal block">Fully private soundproof units, champagne/juice bars, massage tables, and premium gold treatments.</span>
                        </div>
                      </li>
                      <li className="flex gap-2.5 items-start">
                        <span className="font-mono text-base text-pink-500 mt-0.5">🌿</span>
                        <div>
                          <strong className="text-rose-950 block">100% Organic Luxury Cosmetics</strong>
                          <span className="text-[10px] text-neutral-600 leading-normal block">Sourced directly from Swiss botanical beauty houses to ensure safety for all hair and skin types.</span>
                        </div>
                      </li>
                      <li className="flex gap-2.5 items-start">
                        <span className="font-mono text-base text-pink-500 mt-0.5">⏱</span>
                        <div>
                          <strong className="text-rose-950 block">Secured Seat Reservations</strong>
                          <span className="text-[10px] text-neutral-600 leading-normal block">Remotely pre-paid vouchers lock your seat instantly, eliminating traditional hours-long salon lobbies.</span>
                        </div>
                      </li>
                    </ul>
                  </div>

                </div>

              </div>
            )}

            {/* 2. QUEUE LIST BOARD */}
            {activeTab === 'queue' && (
              <div className="animate-fade-in text-center">
                <QueueBoard 
                  currentLang={currentLang}
                  bookings={bookings}
                  servants={servants}
                  services={services}
                />
              </div>
            )}

            {/* 3. SERVANT DAILY AVAILABILITY */}
            {activeTab === 'schedule' && (
              <div className="animate-fade-in">
                <ServantSchedules 
                  currentLang={currentLang}
                  servants={servants}
                  bookings={bookings}
                />
              </div>
            )}

            {/* 4. MANAGEMENT DASHBOARD ADMIN */}
            {activeTab === 'admin' && (
              <div className="animate-fade-in">
                {isAdmin ? (
                  <AdminPanel 
                    currentLang={currentLang}
                    bookings={bookings}
                    servants={servants}
                    services={services}
                    onAddWalkIn={handleNewBooking}
                    onUpdateBookingStatus={handleUpdateBookingStatus}
                    onUpdateServantStatus={handleUpdateServantStatus}
                    publicNotice={publicNotice}
                    onUpdatePublicNotice={handleUpdatePublicNotice}
                  />
                ) : (
                  /* Unauthorized display panel */
                  <div className="bg-white rounded-3xl p-12 border border-rose-100 shadow-md text-center max-w-md mx-auto space-y-4">
                    <span className="text-4xl text-center block">🔒</span>
                    <h4 className="text-lg font-extrabold text-rose-950 tracking-tight">
                      {currentLang === 'en' ? 'Salon Staff Auth Required' : 'የአስተዳዳሪ ፈቃድ ያስፈልጋል'}
                    </h4>
                    
                    <p className="text-xs text-rose-800 leading-relaxed font-semibold">
                      {translations.notLoggedInPlaceholder[currentLang]}
                    </p>

                    <button
                      onClick={() => setIsLoginOpen(true)}
                      className="inline-flex w-full justify-center bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white font-bold py-2.5 rounded-xl transition-all text-xs cursor-pointer"
                    >
                      {currentLang === 'en' ? 'Login as Admin Staff' : 'ማረጋገጫ ግባ'}
                    </button>
                  </div>
                )}
              </div>
            )}

          </motion.div>
        </AnimatePresence>

      </main>

      {/* FOOTER - Professional, quiet, clean */}
      <footer className="border-t border-rose-100 bg-white py-8 px-4 text-center">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-semibold text-rose-800/80">
          
          <div className="text-left space-y-1">
            <p className="font-extrabold text-rose-950"> Lordina Girls Beauty Salon — ሎርዲና የሴቶች የውበት ሳሎን </p>
            <p className="text-[11px] text-rose-500 font-medium">© 2026 Lordina Beauty. All beauty reservations & remote payments secured.</p>
            <p className="text-[11px] text-rose-600 font-bold flex flex-wrap items-center gap-1.5 pt-0.5">
              <span>📞 Customer Support / የደንበኞች ድጋፍ ስልክ:</span> 
              <span className="font-mono text-xs text-rose-800 bg-rose-50 px-2 py-0.5 rounded-lg border border-rose-100">+251 900 123 456</span>
            </p>
          </div>

          {/* Social icons */}
          <div className="flex gap-3 text-rose-400">
            <a href="#instagram" className="hover:text-pink-500 transition-colors cursor-pointer" aria-label="Instagram">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#facebook" className="hover:text-pink-500 transition-colors cursor-pointer" aria-label="Facebook">
              <Facebook className="w-4 h-4" />
            </a>
            <span className="text-rose-100">|</span>
            <span className="text-[10px] text-rose-500 uppercase font-mono font-bold tracking-wider">Gonder, Ethiopia</span>
          </div>

        </div>
      </footer>

      {/* Auth Login Dialog */}
      <LoginModal 
        currentLang={currentLang}
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* PORTAL OVERLAY: FLOATING BUBBLE CHAT INTERPRETER */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 pointer-events-none">
        
        {/* Chat Window Panel */}
        <AnimatePresence>
          {isChatOpen && (
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.92 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.92 }}
              className="w-[330px] sm:w-[370px] max-h-[460px] bg-white shadow-2xl rounded-3xl border border-rose-100 overflow-hidden flex flex-col pointer-events-auto"
            >
              {/* Box Header */}
              <div className="bg-gradient-to-r from-rose-500 to-pink-500 p-4 text-white flex items-center justify-between shadow-sm">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">💇‍♀️</span>
                  <div className="text-left">
                    <h4 className="text-xs font-black uppercase tracking-wider">
                      {currentLang === 'am' ? 'ሎርዲና የውበት ረዳት' : 'Lordina Salon Helper'}
                    </h4>
                    <span className="text-[8px] text-pink-100 flex items-center gap-1 font-semibold">
                      <span className="w-1.5 h-1.5 bg-green-400 rounded-full inline-block animate-pulse"></span>
                      {currentLang === 'am' ? 'መስመር ላይ (ክፍያ እና ወረፋ)' : 'Online Helper for booking & queue'}
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setIsChatOpen(false)}
                  className="bg-white/10 hover:bg-white/20 text-white p-1 rounded-full cursor-pointer transition-all"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Box Messages Body */}
              <div className="flex-1 p-3 overflow-y-auto space-y-3 max-h-[240px] min-h-[200px] bg-neutral-50/50 flex flex-col">
                {chatMessages.map((msg, index) => (
                  <div key={index} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                    <div className={`p-2.5 rounded-2xl text-[11px] leading-relaxed max-w-[85%] ${
                      msg.sender === 'user'
                        ? 'bg-rose-500 text-white rounded-br-none shadow-sm'
                        : 'bg-white text-rose-950 border border-rose-100 rounded-bl-none shadow-sm'
                    }`}>
                      <p className="whitespace-pre-line font-medium">{msg.text}</p>
                    </div>
                    <span className="text-[7px] text-neutral-400 font-mono mt-0.5 px-0.5">{msg.time}</span>
                  </div>
                ))}

                {isTyping && (
                  <div className="flex items-center gap-1 text-rose-500 text-[10px] italic p-1 animate-pulse">
                    <span className="w-1 h-1 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1 h-1 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1 h-1 bg-rose-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    <span className="text-[9px] font-bold text-rose-400">{currentLang === 'am' ? 'ባለሙያችን በመጻፍ ላይ ነው...' : 'Assistant is typing...'}</span>
                  </div>
                )}
              </div>

              {/* Pre-Selected Suggestion Options */}
              <div className="p-2 border-t border-rose-100 bg-white flex flex-wrap gap-1 leading-none">
                <button
                  type="button"
                  onClick={() => sendChatMessage(currentLang === 'am' ? 'እንዴት ቀጠሮ መያዝ እችላለሁ?' : 'How do I book an appointment?')}
                  className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 text-[9px] font-bold rounded-lg transition-all border border-rose-200/40 cursor-pointer"
                >
                  ❓ {currentLang === 'am' ? 'እንዴት ማስያዝ እችላለሁ?' : 'How to book?'}
                </button>
                <button
                  type="button"
                  onClick={() => sendChatMessage(currentLang === 'am' ? 'የሥራ ሰዓት መቼ ነው?' : 'What are the working hours?')}
                  className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 text-[9px] font-bold rounded-lg transition-all border border-rose-200/40 cursor-pointer"
                >
                  🕒 {currentLang === 'am' ? 'የሥራ ሰዓት?' : 'Working hours?'}
                </button>
                <button
                  type="button"
                  onClick={() => sendChatMessage(currentLang === 'am' ? 'ቀጥታ ደውዬ መያዝ እችላለሁ?' : 'Can I book over the phone?')}
                  className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 text-[9px] font-bold rounded-lg transition-all border border-rose-200/40 cursor-pointer"
                >
                  📞 {currentLang === 'am' ? 'በቀጥታ መደወል?' : 'Can I call directly?'}
                </button>
              </div>

              {/* Reply Input Form */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!typedMessage.trim()) return;
                  sendChatMessage(typedMessage);
                  setTypedMessage('');
                }}
                className="p-2 bg-neutral-50 border-t border-rose-100 flex items-center gap-1"
              >
                <input
                  type="text"
                  value={typedMessage}
                  onChange={(e) => setTypedMessage(e.target.value)}
                  placeholder={currentLang === 'am' ? 'ጥያቄዎን እዚህ ይጻፉ...' : 'Ask a question...'}
                  className="flex-1 bg-white border border-rose-200 rounded-xl px-3 py-1.5 text-xs text-rose-950 focus:outline-none focus:ring-1 focus:ring-rose-500 font-sans"
                />
                <button
                  type="submit"
                  className="p-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl shadow-sm transition-all flex items-center justify-center shrink-0 cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </form>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Floating Bubble Badge Button */}
        <button
          type="button"
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="pointer-events-auto h-12 w-12 sm:h-14 sm:w-14 bg-gradient-to-tr from-rose-500 to-pink-500 text-white rounded-full shadow-2xl flex items-center justify-center cursor-pointer transition-all duration-300 hover:scale-105 active:scale-95 group relative border border-rose-200"
          id="floating-chat-bubble-btn"
        >
          {isChatOpen ? (
            <X className="w-6 h-6 stroke-[2.5]" />
          ) : (
            <>
              <MessageCircle className="w-6 h-6 stroke-[2.5] animate-pulse" />
              {/* Bubble notifications count badge */}
              <div className="absolute -top-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-green-500 text-[8px] text-white font-extrabold items-center justify-center">1</span>
              </div>
            </>
          )}
        </button>

      </div>

    </div>
  );
}
