export type ServiceTier = 'Normal' | 'VIP' | 'VVIP';

export interface SalonService {
  id: string;
  nameEn: string;
  nameAm: string;
  category: 'Hair' | 'Makeup' | 'Nails' | 'Spa' | 'VIP Packages';
  basePrice: number; // In ETB (Ethiopian Birr)
  descriptionEn: string;
  descriptionAm: string;
  durationMin: number;
}

export interface Servant {
  id: string;
  name: string;
  nameAm: string;
  roleEn: string;
  roleAm: string;
  rating: number;
  avatar: string;
  specialtiesEn: string[];
  specialtiesAm: string[];
  status: 'Active' | 'On Break' | 'Day Off';
}

export interface Booking {
  id: string;
  customerName: string;
  customerPhone: string;
  serviceId: string;
  servantId: string;
  timeSlot: string; // e.g. "09:00 AM", "10:30 AM"
  tier: ServiceTier;
  paidAmount: number;
  paidStatus: 'Unpaid' | 'Paid';
  paymentMethod?: string;
  screenshot?: string; // base64 string
  screenshotName?: string; // uploaded file name
  queueNo: number;
  status: 'Waiting' | 'Serving' | 'Completed' | 'Cancelled';
  createdAt: string;
  date: string; // e.g. "2026-06-18"
}

export interface Translation {
  [key: string]: {
    en: string;
    am: string;
  };
}
