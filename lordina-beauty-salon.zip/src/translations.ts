export const translations = {
  // Navigation & General
  brandName: {
    en: "Lordina Girls Beauty Salon",
    am: "ሎርዲና የሴቶች የውበት ሳሎን"
  },
  tagline: {
    en: "Luxury Girls Beauty & Wellness Salon — Pamper Yourself in Style",
    am: "የቅንጦት የሴቶች ውበት እና ደህንነት ሳሎን — በላቀ ደረጃ ይንከባከቡ"
  },
  loginBtn: {
    en: "Login",
    am: "መግቢያ"
  },
  logoutBtn: {
    en: "Logout",
    am: "ውጣ"
  },
  bookingTab: {
    en: "Book & Pay",
    am: "ይያዙ እና ይክፈሉ"
  },
  queueTab: {
    en: "Live Queue",
    am: "የቀጥታ ተረኞች"
  },
  scheduleTab: {
    en: "Stylist Free Slots",
    am: "የባለሙያ ነፃ ሰዓቶች"
  },
  adminTab: {
    en: "Salon Management",
    am: "የሳሎኑ ማስተዳደሪያ"
  },
  switchLanguage: {
    en: "አማርኛ",
    am: "English"
  },
  
  // Booking Wizard
  bookNow: {
    en: "Book An Appointment",
    am: "ቀጠሮ ይያዙ"
  },
  stepService: {
    en: "Select Service",
    am: "አገልግሎት ይምረጡ"
  },
  stepTier: {
    en: "Choose Experience",
    am: "ደረጃ ይምረጡ"
  },
  stepStylist: {
    en: "Select Stylist",
    am: "ባለሙያ ይምረጡ"
  },
  stepDateTime: {
    en: "Date & Time",
    am: "ቀን እና ሰዓት"
  },
  stepPayment: {
    en: "Remote Payment",
    am: "ክፍያ ይፈጽሙ"
  },
  stepConfirm: {
    en: "Your Ticket",
    am: "ትኬትዎ"
  },
  
  // Service tiers description
  tierNormal: {
    en: "Normal Tier",
    am: "መደበኛ ደረጃ"
  },
  tierVIP: {
    en: "VIP Tier (+50%)",
    am: "ቪአይፒ ደረጃ (+50%)"
  },
  tierVVIP: {
    en: "VVIP Tier (+100%)",
    am: "ቪቪአይፒ ደረጃ (+100%)"
  },
  tierNormalDesc: {
    en: "Excellent standard service with quality salon products and seating.",
    am: "ደረጃውን የጠበቀ አገልግሎት ከተመረጡ የሳሎን ግብዓቶች ጋር።"
  },
  tierVIPDesc: {
    en: "Private VIP styling chair, top-shelf organic products, customized beverage and head massage.",
    am: "የግል ቪአይፒ መቀመጫ፣ እጅግ ምርጥ ኦርጋኒክ ምርቶች፣ ማሳጅ እና ተጨማሪ መጠጦች።"
  },
  tierVVIPDesc: {
    en: "Secluded VVIP private room, senior celebrity stylist, premium gold caviar products, complimentary fresh juice, absolute private service.",
    am: "ብቸኛ የቪቪአይፒ የግል ክፍል፣ በዋና ባለሙያ የሚሰጥ፣ ነፃ የአትክልትና ፍራፍሬ ጭማቂ፣ ሙሉ ጥበቃ ያለው አገልግሎት።"
  },

  // Payment UI
  payTitle: {
    en: "Mobile Pay Options",
    am: "የሞባይል ክፍያ አማራጮች"
  },
  paySubtitle: {
    en: "Pay remotely safely using preferred Ethiopian digital wallets. All payments are 100% encrypted & secured.",
    am: "በመረጡት የኢትዮጵያ ዲጂታል የክፍያ አማራጭ በተአማኒነት ይክፈሉ።"
  },
  payAmountToPay: {
    en: "Amount Due",
    am: "የሚከፈለው ጠቅላላ"
  },
  payWithTelebirr: {
    en: "Pay with Telebirr",
    am: "በትሌብር ይክፈሉ"
  },
  payWithCBE: {
    en: "Pay with CBE Birr",
    am: "በሲቢኢ ብር ይክፈሉ"
  },
  payWithChapa: {
    en: "Pay with Chapa (Card)",
    am: "በቻፓ (ካርድ/ባንክ) ይክፈሉ"
  },
  paymentSuccess: {
    en: "Payment Successful!",
    am: "ክፍያው በተሳካ ሁኔታ ተጠናቋል!"
  },
  generatingQueue: {
    en: "Securing your spot in queue...",
    am: "የተረኛ ቦታዎን በማዘጋጀት ላይ..."
  },
  btnConfirmPay: {
    en: "Simulate Secure Payment",
    am: "ክፍያን በደህንነት አረጋግጥ"
  },

  // Ticket Receipt
  ticketTitle: {
    en: "Lordina Salon Digital Voucher",
    am: "የሎርዲና ሳሎን ዲጂታል ቫውቸር"
  },
  ticketSubtitle: {
    en: "Show this ticket at the salon counter when arriving.",
    am: "ሳሎን ሲደርሱ ይህንን ዲጂታል ትኬት ካውንተር ላይ ያሳዩ።"
  },
  ticketCode: {
    en: "Booking ID",
    am: "የቀጠሮ መለያ"
  },
  ticketQueue: {
    en: "Queue Spot",
    am: "ከተረኞች ውስጥ ያለዎት ቅደም ተከተል"
  },
  ticketTime: {
    en: "Scheduled Slot",
    am: "የተያዘለት ሰዓት"
  },
  ticketStylist: {
    en: "Assigned Stylist",
    am: "የተመደበው ባለሙያ"
  },
  ticketPricePaid: {
    en: "Price Paid",
    am: "የተከፈለው ዋጋ"
  },
  ticketStatus: {
    en: "Service Tier",
    am: "አገልግሎት ደረጃ"
  },
  estimatedWait: {
    en: "Estimated Wait Time",
    am: "የሚጠበቀው ግምታዊ ሰዓት"
  },
  mins: {
    en: "minutes",
    am: "ደቂቃዎች"
  },
  printTicket: {
    en: "Save / Print Ticket",
    am: "ትኬቱን አስቀምጥ / አትም"
  },

  // Queue Board
  queueBoardTitle: {
    en: "Live Queue Board",
    am: "የቀጥታ ተረኞች ሰሌዳ"
  },
  queueBoardText: {
    en: "Track active spots, serving stations, and wait times in real-time.",
    am: "የእያንዳንዱን ባለሙያ ተረኛ፣ አሁን እየተስተናገዱ ያሉትን እና የጥበቃ ሁኔታን በቀጥታ ይከታተሉ።"
  },
  nowServing: {
    en: "NOW SERVING",
    am: "በመስተናገድ ላይ ያሉ"
  },
  waitingList: {
    en: "WAITING LIST",
    am: "በመጠባበቅ ላይ ያሉ"
  },
  chairNo: {
    en: "Station / Chair",
    am: "ጣቢያ / ወንበር"
  },
  estimatedServing: {
    en: "Estimated wait",
    am: "የተረኛ ጥበቃ"
  },
  noActiveQueue: {
    en: "No active clients in list.",
    am: "በአሁኑ ጊዜ ምንም ተረኛ የለም።"
  },

  // Schedule Timeline
  scheduleTitle: {
    en: "Stylist Daily Availability",
    am: "የባለሙያዎች የቀን ሰንጠረዥ"
  },
  scheduleDesc: {
    en: "Filter by stylist to inspect free, busy, or lunch-break hours.",
    am: "የነፃ ሰዓቶችን፣ ሥራ የበዛባቸውን ወይም የምሳ እረፍቶችን ለመመልከት ባለሙያ ይምረጡ።"
  },
  slotFree: {
    en: "Free Slot",
    am: "ነፃ ሰዓት"
  },
  slotBooked: {
    en: "Booked",
    am: "ተይዟል"
  },
  slotBreak: {
    en: "Lunch/Break",
    am: "እረፍት"
  },

  // Salon Management
  adminTitle: {
    en: "Salon Backstage Management",
    am: "የሳሎን አስተዳደር ዳሽቦርድ"
  },
  adminSubtitle: {
    en: "Add walk-ins, transition queues, modify stylist shifts, or review performance.",
    am: "ተገልጋዮችን እራስዎ ያስገቡ፣ ተረኛ ሂደቶችን ያዘምኑ፣ የባለሙያ ሁኔታዎችን እና ገቢን ይቆጣጠሩ።"
  },
  walkInForm: {
    en: "Register Walk-in Client",
    am: "በአካል የመጣ ደንበኛ መዝግብ"
  },
  clientName: {
    en: "Client Name",
    am: "የደንበኛ ስም"
  },
  phoneNum: {
    en: "Phone Number",
    am: "የስልክ ቁጥር"
  },
  addClientBtn: {
    en: "Add to Queue List",
    am: "ወደ ተረኛ ዝርዝር አስገባ"
  },
  stylistAvailabilityStatus: {
    en: "Stylist Shifts & Availability",
    am: "የባለሙያ ስራና ሁኔታ"
  },
  analyticsSummary: {
    en: "Daily Analytics Dashboard",
    am: "የዕለት ገቢና ስታትስቲክስ"
  },
  totalRevenue: {
    en: "Total Revenue Paid",
    am: "አጠቃላይ የተሰበሰበ ገቢ"
  },
  totalBookings: {
    en: "Total Bookings",
    am: "አጠቃላይ ቀጠሮዎች"
  },
  averageWaitTime: {
    en: "Avg Wait Duration",
    am: "አማካኝ የጥበቃ ሁኔታ"
  },
  vipShare: {
    en: "VIP & VVIP Count",
    am: "የቪአይፒ/ቪቪአይፒ ብዛት"
  },
  changeStatus: {
    en: "Service Status",
    am: "የአገልግሎት ሁኔታ"
  },
  completeService: {
    en: "Finish Session",
    am: "ጨርስ"
  },
  startServiceEn: {
    en: "Start serving",
    am: "አገልግሎት ጀምር"
  },
  cancelService: {
    en: "Cancel Ticket",
    am: "ቀንስ/ሰርዝ"
  },
  activeStylists: {
    en: "Active Stylists Status",
    am: "የባለሙያዎች አሁናዊ ሁኔታ"
  },

  // Login Modal
  loginTitle: {
    en: "Access Lordina Beauty Salon",
    am: "ወደ ሎርዲና ሳሎን ይግቡ"
  },
  loginSubtitle: {
    en: "Login to view personalized beauty passes, past treatments, and exclusive rewards.",
    am: "ያሉዎትን የውበት ቲኬቶች ለመከታተል እና ልዩ ጥቅማ ጥቅሞችን ለማየት ይግቡ።"
  },
  phonePlaceholder: {
    en: "Enter phone or 'admin'",
    am: "ስልክ ቁጥር ያስገቡ ወይም 'admin'"
  },
  passwordLabel: {
    en: "Password (Only for Admin - enter 'admin')",
    am: "የይለፍ ቃል (ለአስተዳዳሪ ብቻ - 'admin')"
  },
  loginSubmit: {
    en: "Login Securely",
    am: "በደህንነት ይግቡ"
  },
  adminHint: {
    en: "💡 Type 'admin' in user/phone and 'admin' in password to login as Salon Manager.",
    am: "💡 እንደ ሳሎኑ አስተዳዳሪ ለመግባት በስልክ ስም 'admin' እና በይለፍ ቃል 'admin' ያስገቡ።"
  },
  loginSuccessUser: {
    en: "Welcome back, beautiful!",
    am: "እንኳን በደህና መጡ!"
  },
  loginSuccessAdmin: {
    en: "Salon Admin access authorized successfully.",
    am: "የሳሎን አስተዳዳሪ ሆነው ገብተዋል!"
  },
  invalidCredentials: {
    en: "Invalid credentials. For admin, use 'admin' / 'admin'.",
    am: "የገቡት መረጃ አልተገኘም። ለአስተዳዳሪ 'admin' ይጠቀሙ።"
  },
  notLoggedInPlaceholder: {
    en: "Please login with your phone or as salon admin to manage/view.",
    am: "ለመስተናገድ በስልክዎ ይግቡ ወይም በአስተዳዳሪነት ይግቡ።"
  },
  welcomeBack: {
    en: "Welcome back",
    am: "እንኳን በደህና ተመለሱ"
  },
  yourActiveBooking: {
    en: "Your Active Pass Ticket",
    am: "የእርስዎ ገቢር ቲኬት"
  }
};
