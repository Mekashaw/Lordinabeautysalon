import React from 'react';
import { Booking, Servant, SalonService } from '../types';
import { translations } from '../translations';
import { 
  Users, UserCheck, Clock, ShieldCheck, Heart, 
  Crown, Award, Sparkles, Smile, Coffee, Scissors 
} from 'lucide-react';

interface QueueBoardProps {
  currentLang: 'en' | 'am';
  bookings: Booking[];
  servants: Servant[];
  services: SalonService[];
}

export default function QueueBoard({
  currentLang,
  bookings,
  servants,
  services
}: QueueBoardProps) {
  // Get service name helper
  const getServiceName = (id: string): string => {
    const s = services.find(x => x.id === id);
    if (!s) return 'Salon Special';
    return currentLang === 'en' ? s.nameEn : s.nameAm;
  };

  // Get servant name helper
  const getServant = (id: string): Servant | undefined => {
    return servants.find(v => v.id === id);
  };

  // Filter bookings for "today" (2026-06-18)
  const activeBookings = bookings.filter(b => b.status !== 'Completed' && b.status !== 'Cancelled');
  
  // Split into "Serving" and "Waiting"
  const servingList = activeBookings.filter(b => b.status === 'Serving');
  const waitingList = activeBookings.filter(b => b.status === 'Waiting');

  return (
    <div className="space-y-6">
      
      {/* Intro Header */}
      <div className="text-center max-w-xl mx-auto">
        <h3 className="text-xl sm:text-2xl font-black text-rose-950 tracking-tight uppercase flex items-center justify-center gap-2">
          <Users className="w-6 h-6 text-rose-500" />
          <span>{translations.queueBoardTitle[currentLang]}</span>
        </h3>
        <p className="text-xs sm:text-sm text-rose-800 mt-1.5 font-medium">
          {translations.queueBoardText[currentLang]}
        </p>
      </div>

      {/* Grid: 2 sections: 1. STYLIST STATIONS, 2. WAIT LIST */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT PANEL: ACTIVE STATIONS & CHAIRS (Currently serving or idle) */}
        <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-rose-100 shadow-md">
          <h4 className="text-xs font-black text-rose-900 tracking-wider uppercase mb-4 flex items-center gap-1.5 border-b border-rose-50 pb-2">
            <Scissors className="w-4 h-4 text-rose-500" />
            <span>{currentLang === 'en' ? 'Stylist Workstations / Chairs' : 'የባለሙያ መስሪያ ሰሌዳ / ወንበር'}</span>
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {servants.map((servant, i) => {
              // Find if this servant has a booking with status === 'Serving'
              const currentServing = servingList.find(b => b.servantId === servant.id);
              const isBreak = servant.status === 'On Break';
              const isOff = servant.status === 'Day Off';
              const isAvailable = servant.status === 'Active';

              return (
                <div 
                  key={servant.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    currentServing
                      ? 'border-rose-200 bg-rose-50/20'
                      : 'border-rose-100 bg-white'
                  }`}
                >
                  {/* Station Chair Indicator header */}
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest bg-rose-50 px-2 py-0.5 rounded-full font-mono">
                      {translations.chairNo[currentLang]} #{i + 1}
                    </span>
                    
                    {/* Visual Status Indicator */}
                    {isOff && (
                      <span className="w-2 h-2 rounded-full bg-neutral-400 block" title="Off duty"></span>
                    )}
                    {isBreak && (
                      <span className="w-2 h-2 rounded-full bg-orange-400 block animate-pulse" title="On Lunch Break"></span>
                    )}
                    {isAvailable && !currentServing && (
                      <span className="w-2 h-2 rounded-full bg-green-500 block" title="Idle, waiting client"></span>
                    )}
                    {isAvailable && currentServing && (
                      <span className="w-2 h-2 rounded-full bg-rose-500 block animate-ping" title="Providing treatment"></span>
                    )}
                  </div>

                  {/* Stylist Profile line */}
                  <div className="flex items-center gap-2.5 mb-3 border-b border-rose-50/50 pb-2.5">
                    <img 
                      src={servant.avatar} 
                      alt="" 
                      className="w-10 h-10 rounded-full object-cover border border-rose-100"
                    />
                    <div className="text-left">
                      <p className="text-xs font-extrabold text-rose-950">
                        {currentLang === 'en' ? servant.name : servant.nameAm}
                      </p>
                      <p className="text-[9px] text-rose-600 font-bold uppercase tracking-wide">
                        {currentLang === 'en' ? servant.roleEn : servant.roleAm}
                      </p>
                    </div>
                  </div>

                  {/* Service Activity Display */}
                  {currentServing ? (
                    <div className="text-left space-y-2 animate-fade-in">
                      {/* Active client */}
                      <div className="flex justify-between items-center gap-2">
                        <span className="text-[11px] font-bold text-rose-900 truncate">
                          👤 {currentServing.customerName}
                        </span>
                        
                        {/* VIP Badging */}
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          currentServing.tier === 'VVIP'
                            ? 'bg-rose-600 text-white shadow shadow-rose-200'
                            : currentServing.tier === 'VIP'
                              ? 'bg-rose-100 text-rose-700 font-bold'
                              : 'bg-neutral-100 text-neutral-600'
                        }`}>
                          {currentServing.tier}
                        </span>
                      </div>
                      
                      <div className="space-y-1">
                        <p className="text-[11px] text-neutral-600 font-medium">
                          💅 {getServiceName(currentServing.serviceId)}
                        </p>
                        <div className="flex justify-between items-center text-[10px] text-rose-600 font-mono">
                          <span>⏱ {currentServing.timeSlot}</span>
                          <span className="bg-rose-50 text-rose-700 px-1.5 py-0.2 rounded font-bold animate-pulse"># {currentServing.queueNo}</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-4 text-xs font-semibold">
                      {isOff ? (
                        <p className="text-neutral-400">📅 {currentLang === 'en' ? 'Off-Duty Today' : 'ዛሬ የለም'}</p>
                      ) : isBreak ? (
                        <p className="text-orange-500 flex items-center justify-center gap-1">
                          <Coffee className="w-3.5 h-3.5" />
                          <span>{currentLang === 'en' ? 'On Break' : 'በዕረፍት ላይ'}</span>
                        </p>
                      ) : (
                        <p className="text-green-600">✨ {currentLang === 'en' ? 'Ready & Vacant' : 'ለመቀበል ዝግጁ ነው'}</p>
                      )}
                    </div>
                  )}

                </div>
              );
            })}
          </div>
        </div>

        {/* RIGHT PANEL: GENERAL WAITING LIST */}
        <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-rose-100 shadow-md">
          <h4 className="text-xs font-black text-rose-900 tracking-wider uppercase mb-4 flex items-center justify-between border-b border-rose-50 pb-2">
            <div className="flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-rose-500" />
              <span>{translations.waitingList[currentLang]}</span>
            </div>
            <span className="text-[10px] font-mono bg-rose-100 text-rose-700 px-2 py-0.5 rounded-full font-bold">
              {waitingList.length} {currentLang === 'en' ? 'Waiting' : 'የሚጠብቁ'}
            </span>
          </h4>

          {waitingList.length === 0 ? (
            <div className="py-12 border-2 border-dashed border-rose-100 rounded-2xl flex flex-col items-center justify-center text-center">
              <Smile className="w-8 h-8 text-rose-200 mb-2" />
              <p className="text-sm font-bold text-rose-800">{translations.noActiveQueue[currentLang]}</p>
              <p className="text-[11px] text-rose-500 max-w-[200px] mt-1">
                {currentLang === 'en' ? 'Book above to secure an open queue spot.' : 'ቦታ ለማስያዝ የይለፍ ቲኬቱን ከላይ ይጫኑ።'}
              </p>
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
              {waitingList.map((booking) => {
                const assignedStylist = getServant(booking.servantId);
                return (
                  <div 
                    key={booking.id}
                    className="p-3 bg-rose-50/20 hover:bg-rose-50/50 border border-rose-100/60 rounded-xl flex items-center justify-between gap-3 text-left transition-colors"
                  >
                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <strong className="text-xs font-extrabold text-rose-950 truncate max-w-[120px]">
                          {booking.customerName}
                        </strong>
                        <span className={`text-[8px] font-black px-1.5 py-0.2 rounded font-mono ${
                          booking.tier === 'VVIP'
                            ? 'bg-rose-600 text-white'
                            : booking.tier === 'VIP'
                              ? 'bg-rose-100 text-rose-700'
                              : 'bg-neutral-100 text-neutral-600'
                        }`}>
                          {booking.tier}
                        </span>
                      </div>
                      
                      <p className="text-[10px] text-neutral-600 font-medium truncate">
                        💇 {getServiceName(booking.serviceId)}
                      </p>

                      <p className="text-[10px] text-rose-800 font-bold">
                        💬 {currentLang === 'en' ? 'Stylist:' : 'ባለሙያ:'} <strong className="text-neutral-800">{assignedStylist ? (currentLang === 'en' ? assignedStylist.name : assignedStylist.nameAm) : 'Unassigned'}</strong>
                      </p>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="block text-[11px] font-black text-rose-950 bg-white border border-rose-100 px-2 py-0.5 rounded font-mono">
                        #{booking.queueNo}
                      </span>
                      <span className="block text-[9px] text-rose-600 font-mono font-medium mt-1">
                        🕒 {booking.timeSlot}
                      </span>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
