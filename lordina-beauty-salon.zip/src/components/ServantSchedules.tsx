import React, { useState } from 'react';
import { Servant, Booking } from '../types';
import { translations } from '../translations';
import { TIMEOBJECTS } from '../data';
import { Clock, Calendar, CheckCircle2, AlertCircle, Coffee } from 'lucide-react';

interface ServantSchedulesProps {
  currentLang: 'en' | 'am';
  servants: Servant[];
  bookings: Booking[];
}

export default function ServantSchedules({
  currentLang,
  servants,
  bookings
}: ServantSchedulesProps) {
  const [selectedServantId, setSelectedServantId] = useState<string>(servants[0]?.id || '');
  const [selectedDate, setSelectedDate] = useState<string>('2026-06-18');

  const selectedServant = servants.find(s => s.id === selectedServantId);

  // Helper to check what occupies a slot
  const checkSlotStatus = (time: string, servantId: string, date: string) => {
    // Check if it's lunch break (e.g. 12:30 PM to 01:00 PM are lunch break hours)
    if (time === '12:30 PM' || time === '01:00 PM') {
      return { status: 'Break', booking: null };
    }

    const booking = bookings.find(b => 
      b.servantId === servantId && 
      b.timeSlot === time && 
      b.date === date &&
      b.status !== 'Cancelled'
    );

    if (booking) {
      return { status: 'Booked', booking };
    }

    return { status: 'Free', booking: null };
  };

  return (
    <div className="bg-white rounded-3xl p-6 border border-rose-100 shadow-md">
      
      {/* Description Headers */}
      <div className="text-center max-w-xl mx-auto mb-6">
        <h3 className="text-xl sm:text-2xl font-black text-rose-950 tracking-tight uppercase flex items-center justify-center gap-2">
          <Clock className="w-6 h-6 text-pink-500" />
          <span>{translations.scheduleTitle[currentLang]}</span>
        </h3>
        <p className="text-xs sm:text-sm text-rose-800 mt-1.5 font-medium">
          {translations.scheduleDesc[currentLang]}
        </p>
      </div>

      {/* Grid: Selector + Timetable Display */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: SELECT THE STYLIST & DATE */}
        <div className="md:col-span-4 space-y-4">
          
          {/* Quick Date Selector */}
          <div>
            <span className="block text-xs font-bold text-rose-900 uppercase tracking-wider mb-2 text-left flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-pink-500" />
              {currentLang === 'en' ? 'Select Date' : 'የቀን መቁጠሪያ'}
            </span>
            <div className="flex gap-2">
              {['2026-06-18', '2026-06-19', '2026-06-20'].map((d) => (
                <button
                  key={d}
                  onClick={() => setSelectedDate(d)}
                  className={`flex-1 py-1.5 px-2 rounded-xl border text-[11px] font-bold text-center cursor-pointer transition-all ${
                    selectedDate === d
                      ? 'border-pink-500 bg-pink-50 text-pink-800 font-extrabold ring-1 ring-pink-500'
                      : 'border-rose-100 bg-white text-rose-900 hover:bg-rose-50/50'
                  }`}
                >
                  {d === '2026-06-18' ? (currentLang === 'en' ? 'Today' : 'ዛሬ') : d === '2026-06-19' ? (currentLang === 'en' ? 'Tomorrow' : 'ነገ') : (currentLang === 'en' ? 'Sat' : 'ቅዳሜ')}
                  <br />
                  <span className="font-mono text-[10px]">{d.split('-')[2]} June</span>
                </button>
              ))}
            </div>
          </div>

          {/* Stylists List Picker */}
          <div>
            <span className="block text-xs font-bold text-rose-900 uppercase tracking-wider mb-2 text-left">
              {currentLang === 'en' ? 'Stylist Roster' : 'የባለሙያዎች ዝርዝር'}
            </span>
            
            <div className="space-y-1.5">
              {servants.map((servant) => {
                const isSelected = servant.id === selectedServantId;
                return (
                  <button
                    key={servant.id}
                    onClick={() => setSelectedServantId(servant.id)}
                    className={`w-full p-2.5 rounded-xl border text-left flex items-center gap-3 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-pink-500 bg-pink-50/20 shadow-sm'
                        : 'border-rose-100 bg-white hover:bg-rose-50/10'
                    }`}
                  >
                    <img 
                      src={servant.avatar} 
                      alt="" 
                      className="w-10 h-10 rounded-full object-cover border border-pink-100"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-rose-950 truncate">
                        {currentLang === 'en' ? servant.name : servant.nameAm}
                      </p>
                      <span className="text-[9px] text-pink-600 font-bold uppercase tracking-wide truncate block">
                        {currentLang === 'en' ? servant.roleEn : servant.roleAm}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: DETAILED DIAL TIMETABLE CARD */}
        <div className="md:col-span-8 bg-rose-50/20 rounded-2xl p-4 sm:p-6 border border-rose-100">
          {selectedServant ? (
            <div className="space-y-4">
              
              {/* Servant Detail Card Header */}
              <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 border border-rose-100 rounded-xl">
                <img 
                  src={selectedServant.avatar} 
                  alt="" 
                  className="w-12 h-12 rounded-full object-cover border border-pink-200"
                />
                <div className="text-center sm:text-left">
                  <h4 className="font-extrabold text-sm text-rose-950">
                    {currentLang === 'en' ? selectedServant.name : selectedServant.nameAm}
                  </h4>
                  <p className="text-[10px] text-pink-600 font-bold uppercase">
                    {currentLang === 'en' ? selectedServant.roleEn : selectedServant.roleAm}
                  </p>
                </div>
                <div className="sm:ml-auto text-xs bg-rose-50 text-rose-800 px-3 py-1.5 rounded-lg border border-rose-100 font-bold">
                  📅 {selectedDate} {currentLang === 'en' ? 'Planner' : 'ቀን እቅድ'}
                </div>
              </div>

              {/* Grid timeline block */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {TIMEOBJECTS.map((timeStr) => {
                  const { status, booking } = checkSlotStatus(timeStr, selectedServant.id, selectedDate);
                  
                  if (status === 'Break') {
                    return (
                      <div 
                        key={timeStr}
                        className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2 text-left"
                      >
                        <Coffee className="w-5 h-5 text-amber-500 flex-shrink-0" />
                        <div>
                          <strong className="text-xs font-mono font-bold text-amber-900 block leading-none">{timeStr}</strong>
                          <span className="text-[9px] font-bold text-amber-700 uppercase tracking-tight">{translations.slotBreak[currentLang]}</span>
                        </div>
                      </div>
                    );
                  }

                  if (status === 'Booked' && booking) {
                    return (
                      <div 
                        key={timeStr} 
                        className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-left"
                      >
                        <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                        <div className="min-w-0">
                          <strong className="text-xs font-mono font-bold text-red-900 block leading-none">{timeStr}</strong>
                          <span className="text-[8px] font-bold text-red-700 uppercase tracking-tight inline-block mr-1">
                            {translations.slotBooked[currentLang]}
                          </span>
                          <span className="text-[9px] text-neutral-600 font-bold truncate block">
                            👤 {booking.customerName.length > 12 ? booking.customerName.substring(0, 10) + '..' : booking.customerName}
                          </span>
                        </div>
                      </div>
                    );
                  }

                  // Default is Free
                  return (
                    <div 
                      key={timeStr} 
                      className="p-3 bg-green-50 border border-green-200 rounded-xl flex items-center gap-2 text-left"
                    >
                      <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0" />
                      <div>
                        <strong className="text-xs font-mono font-bold text-green-900 block leading-none">{timeStr}</strong>
                        <span className="text-[9px] font-bold text-green-700 uppercase tracking-tight">
                          {translations.slotFree[currentLang]}
                        </span>
                      </div>
                    </div>
                  );

                })}
              </div>

            </div>
          ) : (
            <p className="text-rose-500 text-xs font-bold text-center">Please select a stylist to inspect schedules.</p>
          )}
        </div>

      </div>

    </div>
  );
}
