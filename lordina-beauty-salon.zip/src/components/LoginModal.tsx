import React, { useState } from 'react';
import { translations } from '../translations';
import { X, Phone, Lock, Eye, EyeOff, ShieldAlert, Heart } from 'lucide-react';

interface LoginModalProps {
  currentLang: 'en' | 'am';
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (username: string, isAdmin: boolean) => void;
}

export default function LoginModal({ currentLang, isOpen, onClose, onLoginSuccess }: LoginModalProps) {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const normalizedPhone = phone.trim().toLowerCase();
    const normalizedPassword = password.trim();

    if (!normalizedPhone) {
      setErrorMessage(currentLang === 'en' ? 'Please fill in a phone number.' : 'እባክዎ ስልክ ቁጥር ያስገቡ።');
      return;
    }

    // Try admin login
    if (normalizedPhone === 'admin') {
      if (normalizedPassword === 'admin') {
        onLoginSuccess('Salon Manager', true);
        onClose();
        // Clear fields
        setPhone('');
        setPassword('');
      } else {
        setErrorMessage(translations.invalidCredentials[currentLang]);
      }
    } else {
      // Regular client login
      // Validate phone length roughly
      if (normalizedPhone.length < 8) {
        setErrorMessage(currentLang === 'en' ? 'Please enter a valid phone number.' : 'ትክክለኛ ስልክ ቁጥር ያስገቡ።');
        return;
      }
      onLoginSuccess(normalizedPhone, false);
      onClose();
      // Clear fields
      setPhone('');
      setPassword('');
    }
  };

  const handleQuickAdmin = () => {
    setPhone('admin');
    setPassword('admin');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-rose-950/40 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-rose-100 overflow-hidden">
        
        {/* Header Rose Bar */}
        <div className="bg-rose-500 px-6 py-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-white animate-pulse fill-white" />
            <h3 className="text-lg font-bold tracking-tight">{translations.loginTitle[currentLang]}</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20 transition-colors text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <p className="text-sm text-rose-800 font-medium mb-4 leading-relaxed">
            {translations.loginSubtitle[currentLang]}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Phone/Username Input */}
            <div>
              <label className="block text-xs font-bold text-rose-900 uppercase tracking-wider mb-1.5">
                {currentLang === 'en' ? 'Phone Number or Admin' : 'የስልክ ቁጥር ወይም Admin'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Phone className="w-4 h-4 text-rose-400" />
                </div>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder={translations.phonePlaceholder[currentLang]}
                  className="block w-full pl-10 pr-3 py-2.5 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent transition-all text-sm bg-rose-50/30"
                  required
                />
              </div>
            </div>

            {/* Password Input (Only needed for admin login) */}
            {phone.trim().toLowerCase() === 'admin' && (
              <div className="transition-all duration-300">
                <label className="block text-xs font-bold text-rose-900 uppercase tracking-wider mb-1.5">
                  {translations.passwordLabel[currentLang]}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="w-4 h-4 text-rose-400" />
                  </div>
                  <input
                     type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="block w-full pl-10 pr-10 py-2.5 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-2 focus:ring-rose-500 focus:border-transparent transition-all text-sm bg-rose-50/30"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-rose-500 hover:text-rose-700 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            )}

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-red-50 border border-red-100 rounded-xl text-xs text-red-600 font-medium flex items-start gap-2">
                <ShieldAlert className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-rose-500 hover:bg-rose-600 text-white font-semibold py-3 rounded-xl transition-all duration-200 shadow-md hover:shadow-lg text-sm cursor-pointer"
            >
              {translations.loginSubmit[currentLang]}
            </button>
          </form>

          {/* Quick Admin Demo Button */}
          <div className="mt-6 pt-5 border-t border-rose-100 text-center">
            <p className="text-xs text-rose-500 mb-2">
              {translations.adminHint[currentLang]}
            </p>
            <button
              onClick={handleQuickAdmin}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 text-xs font-bold rounded-lg border border-rose-200 transition-colors cursor-pointer"
            >
              <span>Auto-Fill Admin ('admin' / 'admin')</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
}
