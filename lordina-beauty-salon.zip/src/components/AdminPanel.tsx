import React, { useState } from 'react';
import { Booking, Servant, SalonService, ServiceTier } from '../types';
import { translations } from '../translations';
import { TIMEOBJECTS } from '../data';
import { 
  PlusCircle, ToggleLeft, TrendingUp, DollarSign, 
  Clock, Sparkles, Phone, User, Check, Trash, 
  Play, Activity, Eye, RefreshCw, Layers 
} from 'lucide-react';

interface AdminPanelProps {
  currentLang: 'en' | 'am';
  bookings: Booking[];
  servants: Servant[];
  services: SalonService[];
  onAddWalkIn: (booking: Booking) => void;
  onUpdateBookingStatus: (id: string, state: 'Waiting' | 'Serving' | 'Completed' | 'Cancelled') => void;
  onUpdateServantStatus: (id: string, shiftState: 'Active' | 'On Break' | 'Day Off') => void;
  publicNotice: {
    enabled: boolean;
    titleAm: string;
    titleEn: string;
    messageAm: string;
    messageEn: string;
    badgeAm: string;
    badgeEn: string;
    type: 'info' | 'promo' | 'alert';
  };
  onUpdatePublicNotice: (notice: any) => void;
}

export default function AdminPanel({
  currentLang,
  bookings,
  servants,
  services,
  onAddWalkIn,
  onUpdateBookingStatus,
  onUpdateServantStatus,
  publicNotice,
  onUpdatePublicNotice
}: AdminPanelProps) {
  // Form State
  const [walkInName, setWalkInName] = useState('');
  const [walkInPhone, setWalkInPhone] = useState('');
  const [selectedServiceId, setSelectedServiceId] = useState<string>(services[0]?.id || '');
  const [selectedServantId, setSelectedServantId] = useState<string>(servants[0]?.id || '');
  const [selectedTier, setSelectedTier] = useState<ServiceTier>('Normal');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('02:00 PM');
  const [selectedScreenshotBooking, setSelectedScreenshotBooking] = useState<Booking | null>(null);
  const [subTab, setSubTab] = useState<'lobby' | 'financials'>('lobby');
  const [hoveredTier, setHoveredTier] = useState<string | null>(null);

  // Submit Handler
  const handleWalkInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkInName.trim()) {
      alert(currentLang === 'en' ? 'Please specify name.' : 'እባክዎ ስም ያስገቡ።');
      return;
    }

    const selectedServiceObj = services.find(s => s.id === selectedServiceId);
    if (!selectedServiceObj) return;

    // Price Calculation
    let finalAmount = selectedServiceObj.basePrice;
    if (selectedTier === 'VIP') finalAmount = Math.round(finalAmount * 1.5);
    if (selectedTier === 'VVIP') finalAmount = finalAmount * 2;

    // Sequential Queue
    const nextQueueNo = bookings.length > 0 
      ? Math.max(...bookings.map(b => b.queueNo)) + 1
      : 101;

    const walkInBooking: Booking = {
      id: 'WLK' + Math.floor(1000 + Math.random() * 9000),
      customerName: walkInName.trim(),
      customerPhone: walkInPhone.trim() || 'Walk-in Guest',
      serviceId: selectedServiceId,
      servantId: selectedServantId,
      timeSlot: selectedTimeSlot,
      tier: selectedTier,
      paidAmount: finalAmount,
      paidStatus: 'Paid',
      paymentMethod: 'In-Salon Cash',
      queueNo: nextQueueNo,
      status: 'Waiting',
      createdAt: new Date().toISOString(),
      date: '2026-06-18'
    };

    onAddWalkIn(walkInBooking);
    
    // Reset Form
    setWalkInName('');
    setWalkInPhone('');
    setSelectedTier('Normal');
  };

  // Compute Analytics
  const totalPaidRevenue = bookings
    .filter(b => b.status !== 'Cancelled')
    .reduce((sum, b) => sum + b.paidAmount, 0);

  const activeReservationsCount = bookings.filter(b => b.status === 'Waiting' || b.status === 'Serving').length;
  
  const servings = bookings.filter(b => b.status === 'Serving').length;
  
  const vipServicesCount = bookings.filter(b => (b.tier === 'VIP' || b.tier === 'VVIP') && b.status !== 'Cancelled').length;

  // Financial computations
  const tierRevenue: Record<string, number> = bookings
    .filter(b => b.status !== 'Cancelled')
    .reduce((acc, b) => {
      const tier = b.tier || 'Normal';
      acc[tier] = (acc[tier] || 0) + b.paidAmount;
      return acc;
    }, { Normal: 0, VIP: 0, VVIP: 0 } as Record<string, number>);

  const tierCounts: Record<string, number> = bookings
    .filter(b => b.status !== 'Cancelled')
    .reduce((acc, b) => {
      const tier = b.tier || 'Normal';
      acc[tier] = (acc[tier] || 0) + 1;
      return acc;
    }, { Normal: 0, VIP: 0, VVIP: 0 } as Record<string, number>);

  const categoryRevenue: Record<string, number> = bookings
    .filter(b => b.status !== 'Cancelled')
    .reduce((acc, b) => {
      const svc = services.find(s => s.id === b.serviceId);
      const cat = svc ? svc.category : 'Other';
      acc[cat] = (acc[cat] || 0) + b.paidAmount;
      return acc;
    }, {} as Record<string, number>);

  const categoryCounts: Record<string, number> = bookings
    .filter(b => b.status !== 'Cancelled')
    .reduce((acc, b) => {
      const svc = services.find(s => s.id === b.serviceId);
      const cat = svc ? svc.category : 'Other';
      acc[cat] = (acc[cat] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

  const getServiceName = (id: string): string => {
    const s = services.find(x => x.id === id);
    if (!s) return 'Salon Special';
    return currentLang === 'en' ? s.nameEn : s.nameAm;
  };

  const getServantName = (id: string): string => {
    const s = servants.find(x => x.id === id);
    if (!s) return 'A stylist';
    return currentLang === 'en' ? s.name : s.nameAm;
  };

  return (
    <div className="space-y-6">
      
      {/* Segment Header */}
      <div className="text-left">
        <h3 className="text-xl sm:text-2xl font-black text-rose-950 tracking-tight uppercase flex items-center gap-2">
          <Activity className="w-6 h-6 text-rose-500" />
          <span>{translations.adminTitle[currentLang]}</span>
        </h3>
        <p className="text-xs sm:text-sm text-rose-800 font-medium">
          {translations.adminSubtitle[currentLang]}
        </p>
      </div>

      {/* ANALYTICS STATS ROW */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* REVENUE */}
        <div className="p-4 bg-gradient-to-br from-rose-50/60 to-white rounded-2xl border border-rose-100 shadow-sm text-left flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 flex-shrink-0">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-rose-500 block">
              {translations.totalRevenue[currentLang]}
            </span>
            <strong className="text-sm sm:text-lg font-black text-rose-950 font-mono block">
              {totalPaidRevenue} ETB
            </strong>
          </div>
        </div>

        {/* ACTIVE BOOKINGS */}
        <div className="p-4 bg-gradient-to-br from-rose-50 to-white rounded-2xl border border-rose-100 shadow-sm text-left flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 flex-shrink-0">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-rose-500 block">
              {translations.totalBookings[currentLang]}
            </span>
            <strong className="text-sm sm:text-lg font-black text-rose-950 font-mono block">
              {bookings.filter(b => b.status !== 'Cancelled').length} tickets
            </strong>
          </div>
        </div>

        {/* PEAK WAIT */}
        <div className="p-4 bg-gradient-to-br from-rose-50 to-white rounded-2xl border border-rose-100 shadow-sm text-left flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 flex-shrink-0">
            <Clock className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-rose-500 block">
              {translations.averageWaitTime[currentLang]}
            </span>
            <strong className="text-sm sm:text-lg font-black text-rose-950 font-mono block">
              ~{activeReservationsCount * 10} {translations.mins[currentLang]}
            </strong>
          </div>
        </div>

        {/* LOBBY VIP SIZE */}
        <div className="p-4 bg-gradient-to-br from-rose-50 to-white rounded-2xl border border-rose-100 shadow-sm text-left flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 flex-shrink-0">
            <Sparkles className="w-5 h-5 text-rose-500 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-rose-500 block">
              {translations.vipShare[currentLang]}
            </span>
            <strong className="text-sm sm:text-lg font-black text-rose-950 font-mono block">
              {vipServicesCount} treatments
            </strong>
          </div>
        </div>

      </div>

      {/* SUB-TAB SELECTION CONTROLLER */}
      <div className="flex border-b border-rose-100/80 mb-6 gap-2">
        <button
          id="subtab-btn-lobby"
          type="button"
          onClick={() => setSubTab('lobby')}
          className={`px-5 py-3 text-xs sm:text-sm font-black uppercase tracking-wider border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            subTab === 'lobby'
              ? 'border-rose-500 text-rose-950 bg-rose-50/20'
              : 'border-transparent text-neutral-400 hover:text-rose-900 hover:bg-rose-50/10'
          }`}
        >
          <Activity className="w-4 h-4 text-rose-500" />
          <span>{currentLang === 'en' ? '👥 Queue & Lobby Console' : '👥 የተረኞችና የስራ መቆጣጠሪያ'}</span>
        </button>
        <button
          id="subtab-btn-financials"
          type="button"
          onClick={() => setSubTab('financials')}
          className={`px-5 py-3 text-xs sm:text-sm font-black uppercase tracking-wider border-b-2 transition-all cursor-pointer flex items-center gap-2 ${
            subTab === 'financials'
              ? 'border-rose-500 text-rose-950 bg-rose-50/20'
              : 'border-transparent text-neutral-400 hover:text-rose-900 hover:bg-rose-50/10'
          }`}
        >
          <DollarSign className="w-4 h-4 text-rose-500" />
          <span>{currentLang === 'en' ? '📊 Financials Dashboard' : '📊 የፋይናንስና ገቢ መቆጣጠሪያ'}</span>
        </button>
      </div>

      {subTab === 'lobby' ? (
        /* TWO COLUMN GRID: 1. ADD WALK IN & STYLISTS, 2. QUEUE SESSION DISPATCH */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* LEFT COLUMN: Walkin form & Stylists availability */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Walk-in Form Container */}
            <div className="bg-white rounded-3xl p-5 border border-rose-100 shadow-md">
              <h4 className="text-xs font-black text-rose-950 uppercase tracking-wider mb-4 border-b border-rose-50 pb-2 flex items-center gap-1.5 text-left">
                <PlusCircle className="w-4 h-4 text-rose-500" />
                <span>{translations.walkInForm[currentLang]}</span>
              </h4>

              <form onSubmit={handleWalkInSubmit} className="space-y-3.5 text-left">
                
                {/* Customer input */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.clientName[currentLang]}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none">
                      <User className="w-3.5 h-3.5 text-rose-400" />
                    </div>
                    <input
                      type="text"
                      value={walkInName}
                      onChange={(e) => setWalkInName(e.target.value)}
                      placeholder="e.g. Martha Kebede"
                      className="block w-full pl-8 pr-3 py-2 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-rose-50/20"
                      required
                    />
                  </div>
                </div>

                {/* Phone input */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.phoneNum[currentLang]}
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none">
                      <Phone className="w-3.5 h-3.5 text-rose-400" />
                    </div>
                    <input
                      type="tel"
                      value={walkInPhone}
                      onChange={(e) => setWalkInPhone(e.target.value)}
                      placeholder="e.g. 0912123456"
                      className="block w-full pl-8 pr-3 py-2 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-rose-50/20"
                    />
                  </div>
                </div>

                {/* Service Select */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.stepService[currentLang]}
                  </label>
                  <select
                    value={selectedServiceId}
                    onChange={(e) => setSelectedServiceId(e.target.value)}
                    className="block w-full px-2.5 py-2 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-rose-50/20"
                  >
                    {services.map(s => (
                      <option key={s.id} value={s.id}>
                        {currentLang === 'en' ? s.nameEn : s.nameAm} ({s.basePrice} ETB)
                      </option>
                    ))}
                  </select>
                </div>

                {/* Stylist Select */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.stepStylist[currentLang]}
                  </label>
                  <select
                    value={selectedServantId}
                    onChange={(e) => setSelectedServantId(e.target.value)}
                    className="block w-full px-2.5 py-2 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-rose-50/20"
                  >
                    {servants.filter(s => s.status !== 'Day Off').map(s => (
                      <option key={s.id} value={s.id}>
                        {currentLang === 'en' ? s.name : s.nameAm} ({currentLang === 'en' ? s.roleEn : s.roleAm})
                      </option>
                    ))}
                  </select>
                </div>

                {/* Experience Tier choose */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.stepTier[currentLang]}
                  </label>
                  <div className="grid grid-cols-3 gap-1">
                    {(['Normal', 'VIP', 'VVIP'] as ServiceTier[]).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setSelectedTier(t)}
                        className={`py-1 rounded-lg border text-[10px] font-bold transition-all cursor-pointer ${
                          selectedTier === t
                            ? 'bg-rose-500 text-white border-transparent'
                            : 'bg-white text-rose-800 border-rose-100 hover:bg-rose-50'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Dynamic Time selection */}
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                    {translations.ticketTime[currentLang]}
                  </label>
                  <select
                    value={selectedTimeSlot}
                    onChange={(e) => setSelectedTimeSlot(e.target.value)}
                    className="block w-full px-2.5 py-2 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-rose-50/20 card-time-selector"
                  >
                    {TIMEOBJECTS.map(time => (
                      <option key={time} value={time}>{time}</option>
                    ))}
                  </select>
                </div>

                {/* Submit Walk-in */}
                <button
                  type="submit"
                  className="w-full bg-rose-500 hover:bg-rose-600 text-white font-semibold py-2 rounded-xl transition-all text-xs cursor-pointer"
                >
                  {translations.addClientBtn[currentLang]}
                </button>

              </form>
            </div>

            {/* Stylist availability shift console */}
            <div className="bg-white rounded-3xl p-5 border border-rose-100 shadow-md">
              <h4 className="text-xs font-black text-rose-950 uppercase tracking-wider mb-4 border-b border-rose-50 pb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <ToggleLeft className="w-4 h-4 text-rose-500" />
                  {translations.stylistAvailabilityStatus[currentLang]}
                </span>
              </h4>

              <div className="space-y-3 text-left">
                {servants.map((s) => (
                  <div key={s.id} className="flex items-center justify-between gap-2 p-2 border border-rose-50 rounded-xl">
                    <div className="flex items-center gap-2">
                      <img src={s.avatar} alt="" className="w-8 h-8 rounded-full object-cover border" />
                      <div>
                        <p className="text-xs font-bold text-rose-950 truncate max-w-[100px]">
                          {currentLang === 'en' ? s.name : s.nameAm}
                        </p>
                        <span className="text-[8px] bg-rose-50 text-rose-700 px-1 py-0.2 rounded font-mono">
                          {s.status}
                        </span>
                      </div>
                    </div>

                    {/* Actions status togglers */}
                    <div className="flex gap-1 flex-shrink-0">
                      {(['Active', 'On Break', 'Day Off'] as const).map((st) => (
                        <button
                          key={st}
                          onClick={() => onUpdateServantStatus(s.id, st)}
                          className={`px-1.5 py-1 text-[8px] font-extrabold rounded cursor-pointer border ${
                            s.status === st
                              ? st === 'Active'
                                ? 'bg-green-500 text-white border-transparent'
                                : st === 'On Break'
                                  ? 'bg-amber-500 text-white border-transparent'
                                  : 'bg-neutral-500 text-white border-transparent'
                              : 'bg-rose-50 text-rose-800 border-rose-100 hover:bg-rose-100'
                          }`}
                        >
                          {st === 'Active' && (currentLang === 'en' ? 'Active' : 'የስራ')}
                          {st === 'On Break' && (currentLang === 'en' ? 'Break' : 'እረፍት')}
                          {st === 'Day Off' && (currentLang === 'en' ? 'Off' : 'ማረፍ')}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Public announcement board control & configuration panel */}
            <div className="bg-white rounded-3xl p-5 border border-rose-100 shadow-md space-y-4 text-left">
              <h4 className="text-xs font-black text-rose-950 uppercase tracking-wider mb-2 border-b border-rose-50 pb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-rose-950">
                  <Layers className="w-4 h-4 text-rose-500 animate-pulse" />
                  📢 Public Control Post Console
                </span>
                <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                  publicNotice.enabled ? 'bg-green-100 text-green-700' : 'bg-neutral-100 text-neutral-500'
                }`}>
                  {publicNotice.enabled ? 'Published' : 'Offline'}
                </span>
              </h4>

              {/* Enable notice toggle */}
              <div className="flex items-center justify-between gap-2 py-1.5 px-2.5 bg-rose-50/40 rounded-xl border border-rose-100/50">
                <span className="text-xs font-bold text-rose-950">Publish Notice Banner</span>
                <button
                  type="button"
                  onClick={() => onUpdatePublicNotice({ ...publicNotice, enabled: !publicNotice.enabled })}
                  className={`px-3 py-1 text-[10px] font-black uppercase tracking-wider rounded-lg transition-all border cursor-pointer ${
                    publicNotice.enabled 
                      ? 'bg-rose-500 text-white border-transparent shadow' 
                      : 'bg-white text-rose-800 border-rose-100 hover:bg-rose-50'
                  }`}
                >
                  {publicNotice.enabled ? '🟢 Enabled' : '🔴 Disabled'}
                </button>
              </div>

              {/* Visual style select */}
              <div>
                <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                  Visual Notice Preset / Theme
                </label>
                <div className="grid grid-cols-3 gap-1">
                  {[
                    { key: 'promo', label: '💝 Promo (Pink)' },
                    { key: 'info', label: '📢 Info (Blue)' },
                    { key: 'alert', label: '⚠️ Alert (Amber)' }
                  ].map((theme) => (
                    <button
                      key={theme.key}
                      type="button"
                      onClick={() => onUpdatePublicNotice({ ...publicNotice, type: theme.key })}
                      className={`py-1.5 rounded-lg border text-[9px] font-black transition-all cursor-pointer ${
                        publicNotice.type === theme.key
                          ? 'bg-rose-900 text-white border-transparent'
                          : 'bg-white text-rose-800 border-rose-100 hover:bg-rose-50'
                      }`}
                    >
                      {theme.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Title Eng/Amh */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5">
                    Title (English)
                  </label>
                  <input
                    type="text"
                    value={publicNotice.titleEn}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, titleEn: e.target.value })}
                    placeholder="Grand Opening sale..."
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5">
                    ርዕስ (አማርኛ)
                  </label>
                  <input
                    type="text"
                    value={publicNotice.titleAm}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, titleAm: e.target.value })}
                    placeholder="የጎንደር ቅርንጫፍ ታላቅ ቅናሽ..."
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15"
                  />
                </div>
              </div>

              {/* Message Eng/Amh */}
              <div className="space-y-1.5">
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5 font-sans">
                    Message Content (English)
                  </label>
                  <textarea
                    value={publicNotice.messageEn}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, messageEn: e.target.value })}
                    rows={2}
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15 font-sans"
                    placeholder="Detailed English notification..."
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5 font-sans">
                    መልዕክት ይዘት (አማርኛ)
                  </label>
                  <textarea
                    value={publicNotice.messageAm}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, messageAm: e.target.value })}
                    rows={2}
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15 font-sans"
                    placeholder="ዝርዝር የአማርኛ መልዕክት..."
                  />
                </div>
              </div>

              {/* Custom Badges label */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5">
                    Badge text (EN)
                  </label>
                  <input
                    type="text"
                    value={publicNotice.badgeEn}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, badgeEn: e.target.value.toUpperCase() })}
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-rose-900 uppercase tracking-wider mb-0.5">
                    ባጅ ጽሑፍ (AM)
                  </label>
                  <input
                    type="text"
                    value={publicNotice.badgeAm}
                    onChange={(e) => onUpdatePublicNotice({ ...publicNotice, badgeAm: e.target.value })}
                    className="block w-full px-2 py-1.5 border border-rose-200 rounded-xl text-neutral-800 focus:outline-none focus:ring-1 focus:ring-rose-500 text-[11px] bg-rose-50/15"
                  />
                </div>
              </div>
              
              <p className="text-[9px] text-rose-600 italic text-center font-bold">
                ✨ Updates show immediately on client booking dashboard and home notices!
              </p>
            </div>

          </div>

          {/* RIGHT COLUMN: ACTIVE DEPLOYED QUEUES MANAGER */}
          <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-rose-100 shadow-md">
            <h4 className="text-xs font-black text-rose-900 tracking-wider uppercase mb-4 flex items-center justify-between border-b border-rose-50 pb-2">
              <span className="flex items-center gap-1.5">
                <Layers className="w-4 h-4 text-rose-500" />
                {currentLang === 'en' ? 'Dispatch Dashboard Control' : 'የተረኞች ማቆምያና ማሳለፊያ መቆጣጠሪያ'}
              </span>
              <span className="text-[10px] font-mono bg-rose-50 text-rose-700 px-2.5 py-0.5 rounded font-bold animate-pulse">
                Active Session Queue Manager
              </span>
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs min-w-[500px]">
                <thead>
                  <tr className="border-b border-rose-50 text-rose-900 font-bold bg-rose-50/50">
                    <th className="py-2.5 px-2">Ticket / Queue</th>
                    <th className="py-2.5 px-2">Client Guest</th>
                    <th className="py-2.5 px-2">Treatment / Stylist</th>
                    <th className="py-2.5 px-2">Category / Tier</th>
                    <th className="py-2.5 px-2">Status</th>
                    <th className="py-2.5 px-2 text-right">Dispatch Console</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-rose-50/65">
                  {bookings.map((booking) => (
                    <tr 
                      key={booking.id}
                      className={`hover:bg-rose-50/20 transition-all ${
                        booking.status === 'Completed'
                          ? 'opacity-60 bg-neutral-50/30'
                          : booking.status === 'Cancelled'
                            ? 'bg-red-50/10 opacity-40 line-through'
                            : booking.status === 'Serving'
                              ? 'bg-rose-50/30 ring-1 ring-inset ring-rose-100'
                              : ''
                      }`}
                    >
                      {/* Ticket No */}
                      <td className="py-3 px-2 font-mono font-bold text-rose-950">
                        <span className="block text-xs">#{booking.queueNo}</span>
                        <span className="text-[9px] text-rose-500 font-medium">({booking.id})</span>
                      </td>

                      {/* Customer */}
                      <td className="py-3 px-2">
                        <p className="font-extrabold text-neutral-800 leading-none mb-1">{booking.customerName}</p>
                        <p className="text-[9px] text-neutral-500 font-mono">{booking.customerPhone}</p>
                        {booking.screenshot && (
                          <button
                            type="button"
                            onClick={() => setSelectedScreenshotBooking(booking)}
                            className="mt-1 flex items-center gap-1 text-[9px] bg-indigo-50 text-indigo-800 border border-indigo-200 px-1.5 py-0.5 rounded hover:bg-indigo-100 font-bold transition-all cursor-pointer"
                          >
                            <span>🧾 Screen / ደረሰኝ</span>
                          </button>
                        )}
                      </td>

                      {/* Service & Stylist */}
                      <td className="py-3 px-2 space-y-0.5">
                        <p className="font-bold text-rose-900 text-[11px] truncate max-w-[150px]">{getServiceName(booking.serviceId)}</p>
                        <p className="text-[10px] text-rose-600 font-semibold flex items-center gap-0.5">
                          ⭐ {getServantName(booking.servantId)}
                        </p>
                      </td>

                      {/* Tier badge */}
                      <td className="py-3 px-2">
                        <span className={`inline-block text-[9px] text-center font-extrabold px-2 py-0.5 rounded-full ${
                          booking.tier === 'VVIP'
                            ? 'bg-rose-600 text-white'
                            : booking.tier === 'VIP'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-neutral-100 text-neutral-600'
                        }`}>
                          {booking.tier}
                        </span>
                        <span className="block text-[8px] text-rose-600 font-mono mt-0.5 font-medium">💰 {booking.paidAmount} ETB</span>
                      </td>

                      {/* Status Badge */}
                      <td className="py-3 px-2 text-[10px] font-bold">
                        {booking.status === 'Waiting' && (
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 border border-blue-100 rounded-full">
                            {currentLang === 'en' ? 'Lobby Waiting' : 'መጠባበቅ ላይ'}
                          </span>
                        )}
                        {booking.status === 'Serving' && (
                          <span className="px-2 py-0.5 bg-rose-100 text-rose-700 border border-rose-200 rounded-full animate-pulse">
                            {currentLang === 'en' ? 'In Chair' : 'ወንበር ላይ'}
                          </span>
                        )}
                        {booking.status === 'Completed' && (
                          <span className="px-2 py-0.5 bg-green-50 text-green-700 border border-green-200 rounded-full">
                            {currentLang === 'en' ? 'Completed' : 'ተጠናቋል'}
                          </span>
                        )}
                        {booking.status === 'Cancelled' && (
                          <span className="px-2 py-0.5 bg-red-50 text-red-600 border border-red-100 rounded-full line-through">
                            {currentLang === 'en' ? 'Cancelled' : 'ተሰርዟል'}
                          </span>
                        )}
                      </td>

                      {/* Dispatch controls */}
                      <td className="py-3 px-2 text-right">
                        {booking.status === 'Waiting' && (
                          <button
                            onClick={() => onUpdateBookingStatus(booking.id, 'Serving')}
                            className="inline-flex items-center gap-1 bg-blue-50 hover:bg-blue-100 text-blue-700 px-2 py-1.5 rounded-lg border border-blue-200 font-bold text-[10px] cursor-pointer"
                          >
                            <Play className="w-3 h-3 fill-blue-700" />
                            <span>{translations.startServiceEn[currentLang]}</span>
                          </button>
                        )}
                        {booking.status === 'Serving' && (
                          <button
                            onClick={() => onUpdateBookingStatus(booking.id, 'Completed')}
                            className="inline-flex items-center gap-1 bg-green-50 hover:bg-green-100 text-green-700 px-2 py-1.5 rounded-lg border border-green-200 font-bold text-[10px] cursor-pointer"
                          >
                            <Check className="w-3 h-3 stroke-[3]" />
                            <span>{translations.completeService[currentLang]}</span>
                          </button>
                        )}
                        
                        {/* Cancel handler */}
                        {(booking.status === 'Waiting' || booking.status === 'Serving') && (
                          <button
                            onClick={() => onUpdateBookingStatus(booking.id, 'Cancelled')}
                            className="ml-1.5 p-1.5 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg border border-red-100 cursor-pointer inline-block"
                            title="Cancel Booking"
                          >
                            <Trash className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Restore option */}
                        {(booking.status === 'Completed' || booking.status === 'Cancelled') && (
                          <button
                            onClick={() => onUpdateBookingStatus(booking.id, 'Waiting')}
                            className="p-1 px-1.5 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded border border-rose-100 font-mono text-[9px] cursor-pointer"
                            title="Send back to waiting list"
                          >
                            Reopen / አስተካክል
                          </button>
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>

        </div>
      ) : (
        /* FINANCIAL ANALYTICS VIEW */
        <div className="space-y-6 animate-fadeIn">
          {/* Top Tiers Breakdown Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Normal Tier Card */}
            <div id="financials-card-normal" className="bg-white rounded-3xl p-5 border border-rose-100 shadow-sm relative overflow-hidden text-left hover:shadow-md transition-all">
              <div className="absolute top-0 left-0 w-2 h-full bg-rose-400" />
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-black uppercase text-rose-500 tracking-wider">
                    {currentLang === 'en' ? 'Normal Tier' : 'መደበኛ ደረጃ'}
                  </span>
                  <h4 className="text-xl sm:text-2xl font-mono font-black text-rose-950 mt-1">
                    {tierRevenue.Normal.toLocaleString()} <span className="text-xs">ETB</span>
                  </h4>
                </div>
                <div className="bg-rose-50 text-rose-700 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
                  {totalPaidRevenue > 0 ? ((tierRevenue.Normal / totalPaidRevenue) * 100).toFixed(0) : 0}%
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-rose-50 flex justify-between text-[11px] text-neutral-500 font-sans">
                <span>{currentLang === 'en' ? 'Bookings:' : 'ቲኬቶች:'} <strong>{tierCounts.Normal}</strong></span>
                <span>{currentLang === 'en' ? 'Avg Ticket:' : 'አማካይ ክፍያ:'} <strong>{tierCounts.Normal > 0 ? Math.round(tierRevenue.Normal / tierCounts.Normal) : 0} ETB</strong></span>
              </div>
            </div>

            {/* VIP Tier Card */}
            <div id="financials-card-vip" className="bg-white rounded-3xl p-5 border border-rose-100 shadow-sm relative overflow-hidden text-left hover:shadow-md transition-all">
              <div className="absolute top-0 left-0 w-2 h-full bg-amber-400" />
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-black uppercase text-amber-600 tracking-wider">
                    {currentLang === 'en' ? 'VIP Premium Tier' : 'ቪአይፒ ደረጃ'}
                  </span>
                  <h4 className="text-xl sm:text-2xl font-mono font-black text-rose-950 mt-1">
                    {tierRevenue.VIP.toLocaleString()} <span className="text-xs">ETB</span>
                  </h4>
                </div>
                <div className="bg-amber-50 text-amber-700 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
                  {totalPaidRevenue > 0 ? ((tierRevenue.VIP / totalPaidRevenue) * 100).toFixed(0) : 0}%
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-rose-50 flex justify-between text-[11px] text-neutral-500 font-sans">
                <span>{currentLang === 'en' ? 'Bookings:' : 'ቲኬቶች:'} <strong>{tierCounts.VIP}</strong></span>
                <span>{currentLang === 'en' ? 'Avg Ticket:' : 'አማካይ ክፍያ:'} <strong>{tierCounts.VIP > 0 ? Math.round(tierRevenue.VIP / tierCounts.VIP) : 0} ETB</strong></span>
              </div>
            </div>

            {/* VVIP Tier Card */}
            <div id="financials-card-vvip" className="bg-white rounded-3xl p-5 border border-rose-100 shadow-sm relative overflow-hidden text-left hover:shadow-md transition-all">
              <div className="absolute top-0 left-0 w-2 h-full bg-indigo-500" />
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider">
                    {currentLang === 'en' ? 'VVIP Royal Experience' : 'ቪቪአይፒ ደረጃ'}
                  </span>
                  <h4 className="text-xl sm:text-2xl font-mono font-black text-rose-950 mt-1">
                    {tierRevenue.VVIP.toLocaleString()} <span className="text-xs">ETB</span>
                  </h4>
                </div>
                <div className="bg-indigo-50 text-indigo-700 text-[10px] px-2 py-0.5 rounded-full font-mono font-bold">
                  {totalPaidRevenue > 0 ? ((tierRevenue.VVIP / totalPaidRevenue) * 100).toFixed(0) : 0}%
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-rose-50 flex justify-between text-[11px] text-neutral-500 font-sans">
                <span>{currentLang === 'en' ? 'Bookings:' : 'ቲኬቶች:'} <strong>{tierCounts.VVIP}</strong></span>
                <span>{currentLang === 'en' ? 'Avg Ticket:' : 'አማካይ ክፍያ:'} <strong>{tierCounts.VVIP > 0 ? Math.round(tierRevenue.VVIP / tierCounts.VVIP) : 0} ETB</strong></span>
              </div>
            </div>
          </div>

          {/* MAIN GRAPH & BREAKDOWN GRID */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            
            {/* Left side: Interactive SVG Bar Chart */}
            <div className="lg:col-span-8 bg-white rounded-3xl p-6 border border-rose-100 shadow-sm text-left">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-rose-50 pb-3 mb-4">
                <div>
                  <h4 className="text-sm font-black text-rose-950 uppercase tracking-wider">
                    {currentLang === 'en' ? 'Revenue by Experience Tier' : 'የገቢ ማጠቃለያ በየአገልግሎቱ ደረጃ'}
                  </h4>
                  <p className="text-xs text-rose-800/80 font-medium mt-0.5">
                    {currentLang === 'en' ? 'Compare sales performance across Normal, VIP, and VVIP salon configurations.' : 'በመደበኛ፣ ቪአይፒ እና ቪቪአይፒ አገልግሎቶች የተገኘውን ገቢ ያነጻጽሩ።'}
                  </p>
                </div>
                <span className="text-[10px] bg-rose-50 text-rose-700 px-2.5 py-1 rounded font-mono font-extrabold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 bg-rose-500 rounded-full animate-ping" />
                  Live Sync (Firestore)
                </span>
              </div>

              {/* Chart Visual and Interaction Section */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                
                {/* SVG Chart Wrapper */}
                <div id="financial-svg-chart-container" className="md:col-span-8 bg-gradient-to-br from-rose-50/10 to-neutral-50/40 p-3 rounded-2xl border border-rose-50 flex items-center justify-center">
                  <svg viewBox="0 0 500 240" className="w-full h-auto select-none overflow-visible">
                    <defs>
                      <linearGradient id="normalGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#f43f5e" />
                        <stop offset="100%" stopColor="#fda4af" />
                      </linearGradient>
                      <linearGradient id="vipGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#f59e0b" />
                        <stop offset="100%" stopColor="#fde68a" />
                      </linearGradient>
                      <linearGradient id="vvipGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#4f46e5" />
                        <stop offset="100%" stopColor="#c7d2fe" />
                      </linearGradient>
                    </defs>

                    {/* Y Axis Grid Lines & Ticks */}
                    {[0, 0.25, 0.5, 0.75, 1].map((ratio, index) => {
                      const maxVal = Math.max(tierRevenue.Normal, tierRevenue.VIP, tierRevenue.VVIP, 1000);
                      const yPos = 190 - ratio * 150;
                      const valLabel = Math.round(ratio * maxVal);
                      return (
                        <g key={index} className="opacity-80">
                          <line 
                            x1="60" 
                            y1={yPos} 
                            x2="450" 
                            y2={yPos} 
                            stroke="#ffe4e6" 
                            strokeWidth="1" 
                            strokeDasharray="4 4" 
                          />
                          <text 
                            x="50" 
                            y={yPos + 4} 
                            fill="#9f1239" 
                            fontSize="8" 
                            fontWeight="bold" 
                            fontFamily="monospace"
                            textAnchor="end"
                          >
                            {valLabel}
                          </text>
                        </g>
                      );
                    })}

                    {/* Baseline */}
                    <line x1="60" y1="190" x2="450" y2="190" stroke="#f43f5e" strokeWidth="1.5" />

                    {/* Bars drawing */}
                    {[
                      { key: 'Normal', label: currentLang === 'en' ? 'Normal' : 'መደበኛ', val: tierRevenue.Normal, grad: 'url(#normalGrad)', stroke: '#e11d48', xStart: 100 },
                      { key: 'VIP', label: currentLang === 'en' ? 'VIP' : 'ቪአይፒ', val: tierRevenue.VIP, grad: 'url(#vipGrad)', stroke: '#d97706', xStart: 220 },
                      { key: 'VVIP', label: currentLang === 'en' ? 'VVIP' : 'ቪቪአይፒ', val: tierRevenue.VVIP, grad: 'url(#vvipGrad)', stroke: '#4338ca', xStart: 340 }
                    ].map((bar) => {
                      const maxVal = Math.max(tierRevenue.Normal, tierRevenue.VIP, tierRevenue.VVIP, 1000);
                      const barHeight = (bar.val / maxVal) * 150;
                      const finalHeight = Math.max(barHeight, 4); // minimum 4px height so empty bar still hoverable
                      const yPos = 190 - finalHeight;

                      const isHovered = hoveredTier === bar.key;

                      return (
                        <g 
                          key={bar.key}
                          id={`financial-bar-group-${bar.key.toLowerCase()}`}
                          className="cursor-pointer group transition-all"
                          onMouseEnter={() => setHoveredTier(bar.key)}
                          onMouseLeave={() => setHoveredTier(null)}
                        >
                          {/* Main bar rect */}
                          <rect
                            x={bar.xStart}
                            y={yPos}
                            width="60"
                            height={finalHeight}
                            fill={bar.grad}
                            stroke={isHovered ? '#881337' : 'transparent'}
                            strokeWidth="1.5"
                            rx="6"
                            ry="6"
                            className="transition-all duration-300 transform origin-bottom hover:scale-x-105"
                          />

                          {/* Hover effect highlight backdrop */}
                          {isHovered && (
                            <rect
                              x={bar.xStart - 4}
                              y={yPos - 4}
                              width="68"
                              height={finalHeight + 8}
                              fill="transparent"
                              stroke={bar.stroke}
                              strokeWidth="1.5"
                              strokeDasharray="2 2"
                              rx="8"
                              ry="8"
                            />
                          )}

                          {/* Top value badge label */}
                          <text
                            x={bar.xStart + 30}
                            y={yPos - 8}
                            fill="#881337"
                            fontSize="9"
                            fontWeight="900"
                            fontFamily="monospace"
                            textAnchor="middle"
                            className={`transition-opacity duration-200 ${isHovered ? 'opacity-100 scale-105' : 'opacity-90'}`}
                          >
                            {bar.val} ETB
                          </text>

                          {/* X axis labels */}
                          <text
                            x={bar.xStart + 30}
                            y="208"
                            fill="#881337"
                            fontSize="10"
                            fontWeight="bold"
                            textAnchor="middle"
                          >
                            {bar.label}
                          </text>
                          <text
                            x={bar.xStart + 30}
                            y="222"
                            fill="#fda4af"
                            fontSize="8"
                            fontWeight="bold"
                            textAnchor="middle"
                          >
                            ({tierCounts[bar.key]} tkt)
                          </text>
                        </g>
                      );
                    })}
                  </svg>
                </div>

                {/* Interactive Tooltip Card Side Panel */}
                <div className="md:col-span-4 self-stretch flex flex-col justify-between">
                  <div className="bg-rose-50/50 p-4 rounded-2xl border border-rose-100 h-full flex flex-col justify-center space-y-3 text-left">
                    <h5 className="text-[11px] font-black uppercase text-rose-950 tracking-wider border-b border-rose-100/60 pb-1.5 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-rose-500 animate-pulse" />
                      {currentLang === 'en' ? 'Interactive Guide' : 'አሳሽ መመሪያ'}
                    </h5>
                    
                    {hoveredTier ? (
                      <div className="space-y-2 animate-fadeIn text-xs text-rose-950">
                        <p className="font-extrabold text-sm text-rose-900 border-b border-rose-100 pb-1 flex justify-between">
                          <span>{hoveredTier} Tier</span>
                          <span className="font-mono">{tierRevenue[hoveredTier]} ETB</span>
                        </p>
                        <div className="space-y-1.5 text-[11px] text-rose-900/90 font-medium">
                          <p className="flex justify-between">
                            <span>{currentLang === 'en' ? 'Total Tickets:' : 'ጠቅላላ ትኬቶች:'}</span>
                            <span className="font-bold font-mono">{tierCounts[hoveredTier]} appointments</span>
                          </p>
                          <p className="flex justify-between">
                            <span>{currentLang === 'en' ? 'Revenue Share:' : 'የገቢ ድርሻ:'}</span>
                            <span className="font-bold font-mono">{totalPaidRevenue > 0 ? ((tierRevenue[hoveredTier] / totalPaidRevenue) * 100).toFixed(1) : 0}%</span>
                          </p>
                          <p className="flex justify-between">
                            <span>{currentLang === 'en' ? 'Avg Invoice Size:' : 'አማካይ የአገልግሎት ክፍያ:'}</span>
                            <span className="font-bold font-mono">{tierCounts[hoveredTier] > 0 ? Math.round(tierRevenue[hoveredTier] / tierCounts[hoveredTier]) : 0} ETB</span>
                          </p>
                        </div>
                        <p className="text-[9px] text-rose-600 italic font-bold pt-1 border-t border-rose-100/50">
                          {currentLang === 'en' ? '✨ Premium experience config applied dynamically' : '✨ የደረጃ ዋጋ ማሻሻያ በቅጽበት ይሰራል'}
                        </p>
                      </div>
                    ) : (
                      <div className="text-center py-4 space-y-2">
                        <p className="text-xs font-bold text-rose-800">
                          {currentLang === 'en' ? 'Hover over any chart bar' : 'በግራፉ አምዶች ላይ ያንዣብቡ'}
                        </p>
                        <p className="text-[10px] text-neutral-400">
                          {currentLang === 'en' ? 'Move your mouse over the graph bars on the left to reveal instant deep financial performance details.' : 'በእያንዳንዱ የአገልግሎት ደረጃ የተገኘውን ትክክለኛ ገቢ፣ የድርሻ መጠን እና አማካይ ክፍያ በዝርዝር ለማየት አምዶቹ ላይ ያንዣብቡ።'}
                        </p>
                      </div>
                    )}
                  </div>
                </div>

              </div>

            </div>

            {/* Right side: Category-wise list & performance highlights */}
            <div className="lg:col-span-4 space-y-6">
              
              {/* Service Category share */}
              <div id="financials-category-breakdown" className="bg-white rounded-3xl p-5 border border-rose-100 shadow-sm text-left">
                <h4 className="text-xs font-black text-rose-950 uppercase tracking-wider mb-2 border-b border-rose-50 pb-2">
                  💅 {currentLang === 'en' ? 'Service Category Revenue' : 'ገቢ በየአገልግሎት ምድብ'}
                </h4>
                <p className="text-[10px] text-neutral-500 mb-4">
                  {currentLang === 'en' ? 'Distribution of earnings across Hair, Nails, Makeup, and other segments.' : 'በፀጉር፣ ጥፍር፣ ሜካፕ እና ሌሎች ዘርፎች የተገኘ ገቢ ስርጭት።'}
                </p>

                <div className="space-y-4">
                  {Object.keys(categoryRevenue).length > 0 ? (
                    Object.entries(categoryRevenue).map(([cat, amount]) => {
                      const sharePct = totalPaidRevenue > 0 ? (amount / totalPaidRevenue) * 100 : 0;
                      const count = categoryCounts[cat] || 0;
                      return (
                        <div key={cat} className="space-y-1">
                          <div className="flex justify-between items-center text-xs font-bold">
                            <span className="text-rose-950">{cat} Segment</span>
                            <span className="text-rose-700 font-mono">{amount.toLocaleString()} ETB ({sharePct.toFixed(0)}%)</span>
                          </div>
                          {/* Custom Tailwind progress bar */}
                          <div className="w-full bg-rose-50 h-2.5 rounded-full overflow-hidden border border-rose-100/50">
                            <div 
                              className={`h-full rounded-full transition-all duration-500 ${
                                cat === 'Hair' 
                                  ? 'bg-rose-500' 
                                  : cat === 'Nails' 
                                    ? 'bg-amber-500' 
                                    : 'bg-indigo-600'
                              }`} 
                              style={{ width: `${sharePct}%` }}
                            />
                          </div>
                          <div className="flex justify-between text-[9px] text-neutral-400">
                            <span>{count} bookings handled</span>
                            <span>Avg {count > 0 ? Math.round(amount / count) : 0} ETB/item</span>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <p className="text-xs text-neutral-400 italic text-center py-4">{currentLang === 'en' ? 'No financial transactions recorded yet.' : 'እስካሁን ምንም አይነት የገቢ ግብይት አልተመዘገበም።'}</p>
                  )}
                </div>
              </div>

              {/* Performance Highlights */}
              <div id="financials-highlights-panel" className="bg-white rounded-3xl p-5 border border-rose-100 shadow-sm text-left space-y-4">
                <h4 className="text-xs font-black text-rose-950 uppercase tracking-wider border-b border-rose-50 pb-2 flex items-center gap-1">
                  <TrendingUp className="w-4 h-4 text-rose-500" />
                  {currentLang === 'en' ? 'Salon Highlights' : 'የሳሎኑ የሽያጭ ድምቀቶች'}
                </h4>

                <div className="space-y-3 text-xs text-rose-950">
                  {/* Highlight: Average client checkout size */}
                  <div className="flex justify-between items-center p-2.5 bg-rose-50/30 rounded-xl border border-rose-100/40">
                    <div>
                      <span className="block text-[9px] font-bold text-rose-500 uppercase">{currentLang === 'en' ? 'Average Customer Ticket Price' : 'አማካይ የአንድ ደንበኛ ክፍያ'}</span>
                      <strong className="text-sm font-black font-mono">
                        {bookings.filter(b => b.status !== 'Cancelled').length > 0
                          ? Math.round(totalPaidRevenue / bookings.filter(b => b.status !== 'Cancelled').length)
                          : 0} ETB
                      </strong>
                    </div>
                    <div className="text-[10px] text-rose-700 font-bold bg-rose-100/80 px-2 py-0.5 rounded-md font-mono">
                      Per Checkout
                    </div>
                  </div>

                  {/* Highlight: Top Earning Stylist */}
                  <div className="flex justify-between items-center p-2.5 bg-rose-50/30 rounded-xl border border-rose-100/40">
                    <div>
                      <span className="block text-[9px] font-bold text-rose-500 uppercase">{currentLang === 'en' ? 'Star Earning Stylist' : 'የእለቱ ኮከብ ከፍተኛ ገቢ ያስገኘ'}</span>
                      <strong className="text-xs font-black truncate max-w-[130px] block">
                        {(() => {
                          const stylistRevenue = bookings
                            .filter(b => b.status !== 'Cancelled')
                            .reduce((acc, b) => {
                              acc[b.servantId] = (acc[b.servantId] || 0) + b.paidAmount;
                              return acc;
                            }, {} as Record<string, number>);
                          const topStylistId = Object.keys(stylistRevenue).reduce((a, b) => (stylistRevenue[a] || 0) > (stylistRevenue[b] || 0) ? a : b, '');
                          return topStylistId ? getServantName(topStylistId) : 'N/A';
                        })()}
                      </strong>
                    </div>
                    <div className="text-[10px] text-emerald-800 font-bold bg-emerald-100/80 px-2 py-0.5 rounded-md font-mono flex-shrink-0 text-right">
                      {(() => {
                        const stylistRevenue = bookings
                          .filter(b => b.status !== 'Cancelled')
                          .reduce((acc, b) => {
                            acc[b.servantId] = (acc[b.servantId] || 0) + b.paidAmount;
                            return acc;
                          }, {} as Record<string, number>);
                        const topStylistId = Object.keys(stylistRevenue).reduce((a, b) => (stylistRevenue[a] || 0) > (stylistRevenue[b] || 0) ? a : b, '');
                        return topStylistId ? stylistRevenue[topStylistId].toLocaleString() : '0';
                      })()} ETB
                    </div>
                  </div>

                  {/* Highlight: Tickets breakdown ratio */}
                  <div className="p-2.5 bg-rose-50/30 rounded-xl border border-rose-100/40 space-y-1">
                    <span className="block text-[9px] font-bold text-rose-500 uppercase">{currentLang === 'en' ? 'Completed vs Waiting Tickets' : 'የተጠናቀቁ እና በመጠባበቅ ላይ ያሉ ቲኬቶች'}</span>
                    <div className="flex justify-between font-bold text-[10px] mb-0.5 font-mono">
                      <span className="text-emerald-700">Done: {bookings.filter(b => b.status === 'Completed').length}</span>
                      <span className="text-blue-700">Waiting: {bookings.filter(b => b.status === 'Waiting').length}</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>

          </div>

          {/* LOWER SECTION: TRANSACTIONS LIST */}
          <div id="financials-transactions-ledger" className="bg-white rounded-3xl p-6 border border-rose-100 shadow-md text-left">
            <h4 className="text-xs font-black text-rose-950 tracking-wider uppercase mb-1 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-rose-500" />
              {currentLang === 'en' ? 'Detailed Financial Transaction Log' : 'ዝርዝር የክፍያ ግብይቶች መዝገብ'}
            </h4>
            <p className="text-[10px] text-neutral-500 mb-4">
              {currentLang === 'en' ? 'Audit log of all registered active or completed bookings on Firestore.' : 'በFirestore ውስጥ የተመዘገቡ ንቁ ወይም የተጠናቀቁ የክፍያ ግብይቶች መዝገብ።'}
            </p>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs min-w-[500px]">
                <thead>
                  <tr className="border-b border-rose-50 text-rose-900 font-bold bg-rose-50/50">
                    <th className="py-2.5 px-2">ID / Time</th>
                    <th className="py-2.5 px-2">{currentLang === 'en' ? 'Client Guest' : 'ደንበኛ'}</th>
                    <th className="py-2.5 px-2">{currentLang === 'en' ? 'Service Treatment' : 'የተሰጠ አገልግሎት'}</th>
                    <th className="py-2.5 px-2">{currentLang === 'en' ? 'Service Tier' : 'ደረጃ'}</th>
                    <th className="py-2.5 px-2">{currentLang === 'en' ? 'Payment Channel' : 'ክፍያ'}</th>
                    <th className="py-2.5 px-2 text-right">{currentLang === 'en' ? 'Paid Amount' : 'የተከፈለ መጠን'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-rose-50/65">
                  {bookings.filter(b => b.status !== 'Cancelled').length > 0 ? (
                    bookings
                      .filter(b => b.status !== 'Cancelled')
                      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                      .map((b) => (
                        <tr key={b.id} className="hover:bg-rose-50/20 transition-all font-sans">
                          <td className="py-2.5 px-2 font-mono">
                            <p className="font-bold text-rose-950 text-[11px]">#{b.queueNo}</p>
                            <span className="text-[8px] text-neutral-400 block">{new Date(b.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                          </td>
                          <td className="py-2.5 px-2">
                            <p className="font-extrabold text-neutral-800 leading-tight">{b.customerName}</p>
                            <span className="text-[8px] text-neutral-400 font-mono block">{b.customerPhone}</span>
                          </td>
                          <td className="py-2.5 px-2 font-semibold">
                            <p className="text-rose-900 leading-tight">{getServiceName(b.serviceId)}</p>
                            <span className="text-[9px] text-rose-500 block">⭐ {getServantName(b.servantId)}</span>
                          </td>
                          <td className="py-2.5 px-2">
                            <span className={`inline-block text-[8px] font-extrabold px-2 py-0.5 rounded-full ${
                              b.tier === 'VVIP'
                                ? 'bg-rose-600 text-white'
                                : b.tier === 'VIP'
                                  ? 'bg-rose-100 text-rose-800'
                                  : 'bg-neutral-100 text-neutral-600'
                            }`}>
                              {b.tier}
                            </span>
                          </td>
                          <td className="py-2.5 px-2">
                            <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded border border-indigo-100/50 font-bold font-sans">
                              {b.paymentMethod || 'Cash'}
                            </span>
                          </td>
                          <td className="py-2.5 px-2 text-right font-mono font-black text-rose-950">
                            {b.paidAmount.toLocaleString()} ETB
                          </td>
                        </tr>
                      ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-neutral-400 italic">
                        {currentLang === 'en' ? 'No financial transactions recorded yet.' : 'እስካሁን ምንም አይነት የገቢ ግብይት አልተመዘገበም።'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* SCREENSHOT RECEIPT VIEWER MODAL */}
      {selectedScreenshotBooking && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-100 relative space-y-4">
            
            <button
              onClick={() => setSelectedScreenshotBooking(null)}
              className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-600 bg-neutral-100 hover:bg-neutral-200 w-8 h-8 flex items-center justify-center rounded-full transition-all cursor-pointer font-bold text-xs font-sans"
            >
              ✕
            </button>

            <div className="text-center">
              <span className="text-[10px] uppercase font-bold text-rose-500 bg-rose-50 px-2.5 py-1 rounded-full">{selectedScreenshotBooking.paymentMethod} Receipt</span>
              <h3 className="text-sm font-black text-rose-950 mt-2 uppercase tracking-tight font-sans">
                {currentLang === 'en' ? 'Payment Receipt Invoice' : 'የክፍያ ማረጋገጫ ደረሰኝ'}
              </h3>
              <p className="text-xs text-neutral-600 mt-1 font-sans">
                Customer: <strong>{selectedScreenshotBooking.customerName}</strong> ({selectedScreenshotBooking.customerPhone})
              </p>
            </div>

            <div className="border border-rose-100 rounded-2xl overflow-hidden bg-neutral-50 flex items-center justify-center p-2 min-h-[220px]">
              {selectedScreenshotBooking.screenshot ? (
                <img
                  src={selectedScreenshotBooking.screenshot}
                  alt="Uploaded Receipt"
                  className="max-h-[300px] object-contain rounded-xl shadow-sm border border-neutral-200"
                />
              ) : (
                <span className="text-xs text-neutral-400 italic font-sans">No image file found</span>
              )}
            </div>

            <div className="text-[10px] text-neutral-500 text-center font-mono space-y-0.5">
              <p>Voucher ID: {selectedScreenshotBooking.id}</p>
              <p>Amount Authorized: {selectedScreenshotBooking.paidAmount} ETB</p>
              <p>Created At: {new Date(selectedScreenshotBooking.createdAt).toLocaleString()}</p>
            </div>

            <button
              onClick={() => setSelectedScreenshotBooking(null)}
              className="w-full py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs rounded-xl transition-all cursor-pointer font-sans"
            >
              {currentLang === 'en' ? 'Close Window' : 'ዝጋ'}
            </button>

          </div>
        </div>
      )}

    </div>
  );
}
