import React, { useState, useEffect } from 'react';
import { SalonService, Servant, Booking, ServiceTier } from '../types';
import { translations } from '../translations';
import { TIMEOBJECTS } from '../data';
import { 
  Sparkles, Check, ChevronRight, ChevronLeft, Calendar as CalendarIcon, 
  Clock, DollarSign, Award, ThumbsUp, Crown, Zap, Wallet, CreditCard, 
  Smile, UserCheck, Ticket, CalendarDays, Loader2
} from 'lucide-react';

interface BookingWizardProps {
  currentLang: 'en' | 'am';
  services: SalonService[];
  servants: Servant[];
  bookings: Booking[];
  isLoggedIn: boolean;
  loggedInName: string | null;
  onNewBooking: (booking: Booking) => void;
}

export default function BookingWizard({
  currentLang,
  services,
  servants,
  bookings,
  isLoggedIn,
  loggedInName,
  onNewBooking
}: BookingWizardProps) {
  // Steps: 1: Service, 2: Tier, 3: Stylist, 4: DateTime, 5: Pay, 6: Ticket
  const [step, setStep] = useState(1);
  const wizardRef = React.useRef<HTMLDivElement>(null);

  // Selection States
  const [selectedCategory, setSelectedCategory] = useState<string>('Hair');
  const [selectedService, setSelectedService] = useState<SalonService | null>(null);
  const [selectedTier, setSelectedTier] = useState<ServiceTier>('Normal');
  const [selectedServant, setSelectedServant] = useState<Servant | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>('2026-06-18');
  const [selectedTime, setSelectedTime] = useState<string>('');
  
  // Customer Info
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentProvider, setPaymentProvider] = useState<'Telebirr' | 'CBE' | 'Dashen' | 'Abyssinia'>('Telebirr');
  const [screenshotBase64, setScreenshotBase64] = useState<string>('');
  const [screenshotName, setScreenshotName] = useState<string>('');
  const [copied, setCopied] = useState(false);
  
  // App states
  const [isProcessing, setIsProcessing] = useState(false);
  const [completedBooking, setCompletedBooking] = useState<Booking | null>(null);

  // Auto prefill customer details if logged in
  useEffect(() => {
    if (isLoggedIn && loggedInName) {
      if (loggedInName.toLowerCase() !== 'admin') {
        setCustomerName(loggedInName.split(' ')[0]);
        setCustomerPhone(loggedInName);
      }
    }
  }, [isLoggedIn, loggedInName]);

  const bankAccounts = {
    Telebirr: {
      nameEn: 'Telebirr (Mobile Wallet)',
      nameAm: 'ቴሌብር (የሞባይል ስም/ስልክ)',
      number: '0911223344',
      holderEn: 'Lordina Girls Beauty Salon',
      holderAm: 'ሎርዲና የሴቶች የውበት ሳሎን',
    },
    CBE: {
      nameEn: 'Commercial Bank of Ethiopia (CBE)',
      nameAm: 'የኢትዮጵያ ንግድ ባንክ (CBE)',
      number: '1000123456789',
      holderEn: 'Lordina Girls Beauty Salon',
      holderAm: 'ሎርዲና የሴቶች የውበት ሳሎን',
    },
    Dashen: {
      nameEn: 'Dashen Bank',
      nameAm: 'የዳሽን ባንክ (Dashen)',
      number: '5078123456789',
      holderEn: 'Lordina Girls Beauty Salon',
      holderAm: 'ሎርዲና የሴቶች የውበት ሳሎን',
    },
    Abyssinia: {
      nameEn: 'Bank of Abyssinia',
      nameAm: 'የአቢሲኒያ ባንክ (Abyssinia)',
      number: '2012123456789',
      holderEn: 'Lordina Girls Beauty Salon',
      holderAm: 'ሎርዲና የሴቶች የውበት ሳሎን',
    }
  };

  const handleCopy = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      try {
        document.execCommand('copy');
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (e) {
        console.error(e);
      }
      document.body.removeChild(textArea);
    }
  };

  const processUploadedFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert(currentLang === 'en' ? 'Please upload an image file!' : 'እባክዎ የምስል ፋይል ያያይዙ!');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target && typeof e.target.result === 'string') {
        setScreenshotBase64(e.target.result);
        setScreenshotName(file.name);
      }
    };
    reader.readAsDataURL(file);
  };

  // Pricing helper
  const calculatePrice = (base: number, tier: ServiceTier): number => {
    if (tier === 'VIP') return Math.round(base * 1.5);
    if (tier === 'VVIP') return base * 2;
    return base;
  };

  // Categories
  const categories = ['Hair', 'Makeup', 'Nails', 'Spa', 'VIP Packages'];

  // Timetable helper: check if slot is booked for selected stylized servant on selected date
  const isTimeSlotBooked = (time: string, servantId: string, date: string): boolean => {
    return bookings.some(b => 
      b.servantId === servantId && 
      b.timeSlot === time && 
      b.date === date &&
      b.status !== 'Cancelled'
    );
  };

  const handleNext = () => {
    if (step === 1 && !selectedService) return;
    if (step === 3 && !selectedServant) return;
    if (step === 4 && !selectedTime) return;
    setStep(prev => prev + 1);
  };

  const handleBack = () => {
    setStep(prev => prev - 1);
  };

  // Execute Simulation
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      alert(currentLang === 'en' ? 'Customer name and phone number are strictly mandatory!' : 'የደንበኞች ስም እና ስልክ ቁጥር ማስገባት ግዴታ ነው!');
      return;
    }

    if (!screenshotBase64) {
      alert(currentLang === 'en' ? 'Please upload a screenshot of your payment receipt to complete the verification!' : 'እባክዎ የተጠናቀቀውን ክፍያ ስክሪንሾት ያያይዙ!');
      return;
    }

    setIsProcessing(true);
    
    // Simulate API network latency
    setTimeout(() => {
      const basePr = selectedService ? selectedService.basePrice : 0;
      const finalPrice = calculatePrice(basePr, selectedTier);
      
      // Compute automatic sequential queue number
      const nextQueueNo = bookings.length > 0
        ? Math.max(...bookings.map(b => b.queueNo)) + 1
        : 101;

      // Unique ticket code
      const ticketId = 'LDS' + Math.floor(1000 + Math.random() * 9000);

      const newBookingObj: Booking = {
        id: ticketId,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        serviceId: selectedService?.id || '',
        servantId: selectedServant?.id || '',
        timeSlot: selectedTime,
        tier: selectedTier,
        paidAmount: finalPrice,
        paidStatus: 'Paid',
        paymentMethod: paymentProvider,
        screenshot: screenshotBase64,
        screenshotName: screenshotName,
        queueNo: nextQueueNo,
        status: 'Waiting',
        createdAt: new Date().toISOString(),
        date: selectedDate
      };

      onNewBooking(newBookingObj);
      setCompletedBooking(newBookingObj);
      setIsProcessing(false);
      setStep(6);
    }, 2000);
  };

  const resetWizard = () => {
    setSelectedService(null);
    setSelectedTier('Normal');
    setSelectedServant(null);
    setSelectedTime('');
    setCompletedBooking(null);
    setScreenshotBase64('');
    setScreenshotName('');
    setStep(1);
  };

  return (
    <div ref={wizardRef} className="bg-white rounded-3xl border border-rose-100 shadow-xl overflow-hidden min-h-[580px] flex flex-col scroll-mt-24">
      
      {/* Wizard Step Progress Indicator */}
      {step < 6 && (
        <div className="bg-rose-50/70 border-b border-rose-100 p-4">
          <div className="max-w-md mx-auto flex items-center justify-between text-xs font-semibold text-rose-500">
            <span className={step >= 1 ? "text-rose-900 font-bold" : ""}>1. {translations.stepService[currentLang]}</span>
            <ChevronRight className="w-3.5 h-3.5 text-rose-300" />
            <span className={step >= 2 ? "text-rose-900 font-bold" : ""}>2. {translations.stepTier[currentLang]}</span>
            <ChevronRight className="w-3.5 h-3.5 text-rose-300" />
            <span className={step >= 3 ? "text-rose-900 font-bold" : ""}>3. {translations.stepStylist[currentLang]}</span>
            <ChevronRight className="w-3.5 h-3.5 text-rose-300" />
            <span className={step >= 4 ? "text-rose-900 font-bold" : ""}>4. {translations.stepDateTime[currentLang]}</span>
            <ChevronRight className="w-3.5 h-3.5 text-rose-300" />
            <span className={step >= 5 ? "text-rose-900 font-bold" : ""}>5. {translations.stepPayment[currentLang]}</span>
          </div>
          {/* Progress Bar */}
          <div className="h-1.5 w-full bg-rose-100/50 rounded-full mt-3 overflow-hidden">
            <div 
              className="h-full bg-rose-500 transition-all duration-300 rounded-full"
              style={{ width: `${(step / 5) * 100}%` }}
            ></div>
          </div>
        </div>
      )}

      {/* Main Form Content area */}
      <div className="flex-1 p-6 flex flex-col">
        
        {/* STEP 1: Select Service Category and Service */}
        {step === 1 && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center max-w-sm mx-auto mb-6">
                <span className="inline-flex py-1 px-3 bg-rose-100 text-rose-700 text-xs font-bold rounded-full mb-2">Step 1</span>
                <h4 className="text-lg font-extrabold text-rose-950 uppercase tracking-tight">
                  {currentLang === 'en' ? 'Select Salon Treatments' : 'አገልግሎቶችን ይምረጡ'}
                </h4>
                <p className="text-xs text-rose-800 mt-1">
                  {currentLang === 'en' ? 'Explore specialized services tailored by Lordina.' : 'እባክዎ ለማስያዝ የሚፈልጉትን አገልግሎት ይመርጡ።'}
                </p>
              </div>

              {/* Categorical tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-3 scrollbar-none scroll-smooth">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      setSelectedService(null);
                    }}
                    className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-250 cursor-pointer ${
                      selectedCategory === cat 
                        ? 'bg-rose-500 text-white shadow-md' 
                        : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-100'
                    }`}
                  >
                    {cat === 'VIP Packages' && '👑 '}
                    {cat === 'Hair' && (currentLang === 'en' ? 'Hair' : 'ፀጉር')}
                    {cat === 'Makeup' && (currentLang === 'en' ? 'Makeup/Facial' : 'ሜካፕ/ፊት')}
                    {cat === 'Nails' && (currentLang === 'en' ? 'Nails' : 'ጥፍር')}
                    {cat === 'Spa' && (currentLang === 'en' ? 'Massage & Spa' : 'ማሳጅና የሰውነት')}
                    {cat === 'VIP Packages' && (currentLang === 'en' ? 'Crown VIP Bundles' : 'የሙሽሮች ሙሉ ፓኬጅ')}
                  </button>
                ))}
              </div>

              {/* Grid of services in selected category */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4">
                {services
                  .filter(s => s.category === selectedCategory)
                  .map((service) => {
                    const isSelected = selectedService?.id === service.id;
                    return (
                      <div
                        key={service.id}
                        onClick={() => setSelectedService(service)}
                        className={`p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 select-none flex flex-col justify-between ${
                          isSelected
                            ? 'border-rose-500 bg-rose-50/60 ring-2 ring-rose-300 shadow-md'
                            : 'border-rose-100 hover:border-rose-300 hover:bg-rose-50/20'
                        }`}
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <span className="font-bold text-sm sm:text-base text-rose-950 leading-tight">
                              {currentLang === 'en' ? service.nameEn : service.nameAm}
                            </span>
                            {isSelected && (
                              <span className="w-5 h-5 bg-rose-500 text-white rounded-full flex items-center justify-center flex-shrink-0 animate-scale-up">
                                <Check className="w-3 h-3 stroke-[3]" />
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-neutral-600 line-clamp-2 leading-relaxed">
                            {currentLang === 'en' ? service.descriptionEn : service.descriptionAm}
                          </p>
                        </div>
                        
                        <div className="flex items-center justify-between border-t border-rose-50 mt-3 pt-2">
                          <span className="text-xs text-rose-500 font-bold bg-rose-50 px-2 py-0.5 rounded-full">
                            🕒 {service.durationMin} {currentLang === 'en' ? 'mins' : 'ደቂቃ'}
                          </span>
                          <span className="text-sm font-black text-rose-950 font-mono">
                            {service.basePrice} ETB
                          </span>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>

            {/* Step Controls */}
            <div className="flex justify-end pt-4 border-t border-rose-100 mt-6 md:mt-2">
              <button
                onClick={handleNext}
                disabled={!selectedService}
                className={`flex items-center gap-1.5 px-6 py-3 rounded-full text-sm font-semibold shadow-md transition-all duration-200 cursor-pointer ${
                  selectedService 
                    ? 'bg-rose-500 hover:bg-rose-600 text-white active:scale-95' 
                    : 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                }`}
              >
                <span>{currentLang === 'en' ? 'Choose Styling Tier' : 'ቀጥል'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Choose Experience Tier (Normal, VIP, VVIP) */}
        {step === 2 && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center max-w-sm mx-auto mb-6">
                <span className="inline-flex py-1 px-3 bg-rose-100 text-rose-700 text-xs font-bold rounded-full mb-2">Step 2</span>
                <h4 className="text-lg font-extrabold text-rose-950 uppercase tracking-tight">
                  {currentLang === 'en' ? 'Select Service Tier' : 'የአገልግሎት ደረጃ ይምረጡ'}
                </h4>
                <p className="text-xs text-rose-800 mt-1">
                  {currentLang === 'en' ? 'Upgrade your pamper session with our luxurious tier experiences.' : 'የእርስዎን ምርጫ ደረጃ በመምረጥ አገልግሎቱን ያሳድጉ።'}
                </p>
              </div>

              {/* Display base service info */}
              {selectedService && (
                <div className="p-3 bg-rose-50/40 rounded-xl mb-4 border border-rose-100 flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">Selected Treatment</span>
                    <p className="text-sm font-bold text-rose-900 leading-tight">
                      {currentLang === 'en' ? selectedService.nameEn : selectedService.nameAm}
                    </p>
                  </div>
                  <div className="text-right font-mono text-rose-900 text-sm font-black">
                    {translations.payAmountToPay[currentLang]}: <span className="text-rose-600">{calculatePrice(selectedService.basePrice, selectedTier)} ETB</span>
                  </div>
                </div>
              )}

              {/* Experience Tiers Options */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Normal */}
                <div
                  onClick={() => setSelectedTier('Normal')}
                  className={`p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 relative flex flex-col justify-between select-none ${
                    selectedTier === 'Normal'
                      ? 'border-neutral-400 bg-neutral-50/50 ring-2 ring-neutral-400 shadow-md'
                      : 'border-rose-100 hover:border-neutral-300 hover:bg-neutral-50/10'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5 mb-2">
                      <div className="w-5 h-5 rounded-full bg-neutral-100 flex items-center justify-center">
                        <ThumbsUp className="w-3 h-3 text-neutral-600" />
                      </div>
                      <span className="font-extrabold text-sm text-neutral-800 uppercase tracking-tight">
                        {translations.tierNormal[currentLang]}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 leading-relaxed mb-4">
                      {translations.tierNormalDesc[currentLang]}
                    </p>
                  </div>
                  <div className="border-t border-neutral-100 pt-2 text-right">
                    <span className="text-xs font-bold text-neutral-900 bg-neutral-100 px-2.5 py-1 rounded-full font-mono">
                      {selectedService?.basePrice} ETB
                    </span>
                  </div>
                  {selectedTier === 'Normal' && (
                    <span className="absolute top-3 right-3 w-4 h-4 bg-neutral-600 text-white rounded-full flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>

                {/* VIP */}
                <div
                  onClick={() => setSelectedTier('VIP')}
                  className={`p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 relative flex flex-col justify-between select-none ${
                    selectedTier === 'VIP'
                      ? 'border-rose-500 bg-rose-50/40 ring-2 ring-rose-500 shadow-md'
                      : 'border-rose-100 hover:border-rose-300 hover:bg-rose-50/10'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5 mb-2">
                      <div className="w-5 h-5 rounded-full bg-rose-100 flex items-center justify-center">
                        <Crown className="w-3 h-3 text-rose-600" />
                      </div>
                      <span className="font-extrabold text-sm text-rose-700 uppercase tracking-tight flex items-center gap-1">
                        {translations.tierVIP[currentLang]}
                        <span className="text-[10px] bg-rose-200 text-rose-800 px-1 py-0.2 rounded font-bold">Pop</span>
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 leading-relaxed mb-4">
                      {translations.tierVIPDesc[currentLang]}
                    </p>
                  </div>
                  <div className="border-t border-rose-100 pt-2 text-right">
                    <span className="text-xs font-bold text-rose-700 bg-rose-100 px-2.5 py-1 rounded-full font-mono">
                      {selectedService ? calculatePrice(selectedService.basePrice, 'VIP') : 0} ETB
                    </span>
                  </div>
                  {selectedTier === 'VIP' && (
                    <span className="absolute top-3 right-3 w-4 h-4 bg-rose-500 text-white rounded-full flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>

                {/* VVIP */}
                <div
                  onClick={() => setSelectedTier('VVIP')}
                  className={`p-4 rounded-2xl border text-left cursor-pointer transition-all duration-200 relative flex flex-col justify-between select-none ${
                    selectedTier === 'VVIP'
                      ? 'border-rose-600 bg-rose-50/60 ring-2 ring-rose-500 shadow-md'
                      : 'border-rose-100 hover:border-rose-300 hover:bg-rose-50/20'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-1.5 mb-2">
                      <div className="w-5 h-5 rounded-full bg-rose-200 flex items-center justify-center">
                        <Zap className="w-3 h-3 text-rose-700 fill-rose-700" />
                      </div>
                      <span className="font-extrabold text-sm text-rose-800 uppercase tracking-tight">
                        {translations.tierVVIP[currentLang]}
                      </span>
                    </div>
                    <p className="text-xs text-neutral-600 leading-relaxed mb-4">
                      {translations.tierVVIPDesc[currentLang]}
                    </p>
                  </div>
                  <div className="border-t border-rose-200 pt-2 text-right">
                    <span className="text-xs font-bold text-rose-800 bg-rose-200 px-2.5 py-1 rounded-full font-mono">
                      {selectedService ? calculatePrice(selectedService.basePrice, 'VVIP') : 0} ETB
                    </span>
                  </div>
                  {selectedTier === 'VVIP' && (
                    <span className="absolute top-3 right-3 w-4 h-4 bg-rose-600 text-white rounded-full flex items-center justify-center">
                      <Check className="w-2.5 h-2.5 stroke-[3]" />
                    </span>
                  )}
                </div>

              </div>
            </div>

            {/* Step Controls */}
            <div className="flex justify-between pt-4 border-t border-rose-100 mt-6 md:mt-2">
              <button
                onClick={handleBack}
                className="flex items-center gap-1.5 px-4.5 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-full text-xs font-bold transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{currentLang === 'en' ? 'Back' : 'በኋላ'}</span>
              </button>
              <button
                onClick={handleNext}
                className="flex items-center gap-1.5 px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white rounded-full text-sm font-semibold shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <span>{currentLang === 'en' ? 'Choose Stylist' : 'ባለሙያ ምረጥ'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: Choose Stylist (Servant) */}
        {step === 3 && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center max-w-sm mx-auto mb-6">
                <span className="inline-flex py-1 px-3 bg-rose-100 text-rose-700 text-xs font-bold rounded-full mb-2">Step 3</span>
                <h4 className="text-lg font-extrabold text-rose-950 uppercase tracking-tight">
                  {translations.stepStylist[currentLang]}
                </h4>
                <p className="text-xs text-rose-800 mt-1">
                  {currentLang === 'en' ? 'Select our licensed stylist to assign your treatments. Lordina is owner & premium tier master.' : 'አገልግሎትዎን እንዲያከናውንሎት የሚመርጡትን ባለሙያ ይምረጡ።'}
                </p>
              </div>

              {/* Grid of Stylists */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {servants.map((servant) => {
                  const isSelected = selectedServant?.id === servant.id;
                  const isActive = servant.status === 'Active';
                  return (
                    <div
                      key={servant.id}
                      onClick={() => {
                        if (!isActive) return;
                        setSelectedServant(servant);
                      }}
                      className={`p-4 rounded-2xl border text-left flex flex-col justify-between relative select-none ${
                        !isActive 
                          ? 'opacity-50 bg-neutral-50 border-neutral-100 cursor-not-allowed'
                          : isSelected
                            ? 'border-rose-500 bg-rose-50/40 ring-2 ring-rose-500 shadow-md cursor-pointer'
                            : 'border-rose-100 hover:border-rose-300 hover:bg-rose-50/10 cursor-pointer'
                      }`}
                    >
                      {/* Avatar and Info Header */}
                      <div className="flex items-center gap-3 mb-3">
                        <img 
                          src={servant.avatar} 
                          alt={servant.name} 
                          className="w-12 h-12 rounded-full object-cover border border-rose-200"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="flex items-center gap-1">
                            <span className="font-extrabold text-sm text-rose-950">
                              {currentLang === 'en' ? servant.name : servant.nameAm}
                            </span>
                          </div>
                          <span className="text-[10px] text-rose-600 font-bold uppercase tracking-wide">
                            {currentLang === 'en' ? servant.roleEn : servant.roleAm}
                          </span>
                        </div>
                      </div>

                      {/* Bio details / specialties */}
                      <div className="mb-3">
                        <div className="flex flex-wrap gap-1">
                          {(currentLang === 'en' ? servant.specialtiesEn : servant.specialtiesAm).map((spec, index) => (
                            <span key={index} className="text-[9px] bg-rose-50 border border-rose-100 text-rose-800 font-bold px-1.5 py-0.5 rounded">
                              {spec}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Rating & status */}
                      <div className="flex items-center justify-between border-t border-rose-50/50 pt-2.5 mt-2 text-xs">
                        <span className="text-amber-500 font-bold flex items-center gap-0.5">
                          ★ <strong className="text-rose-950">{servant.rating}</strong>
                        </span>
                        
                        {/* Servant Availability Badges */}
                        {isActive ? (
                          <span className="px-2 py-0.5 bg-green-50 text-green-700 border border-green-200 rounded font-bold text-[10px]">
                            {currentLang === 'en' ? 'Available' : 'የስራ ላይ'}
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 bg-red-50 text-red-700 border border-red-200 rounded font-bold text-[10px]">
                            {servant.status === 'On Break' 
                              ? (currentLang === 'en' ? 'On Break' : 'በእረፍት ላይ') 
                              : (currentLang === 'en' ? 'Off-Duty' : 'ዛሬ የለም')}
                          </span>
                        )}
                      </div>

                      {isSelected && isActive && (
                        <span className="absolute top-3 right-3 w-4 h-4 bg-rose-500 text-white rounded-full flex items-center justify-center">
                          <Check className="w-2.5 h-2.5 stroke-[3]" />
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Step Controls */}
            <div className="flex justify-between pt-4 border-t border-rose-100 mt-6 md:mt-2">
              <button
                onClick={handleBack}
                className="flex items-center gap-1.5 px-4.5 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-full text-xs font-bold transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{currentLang === 'en' ? 'Back' : 'በኋላ'}</span>
              </button>
              <button
                onClick={handleNext}
                disabled={!selectedServant}
                className={`flex items-center gap-1.5 px-6 py-3 rounded-full text-sm font-semibold shadow-md transition-all cursor-pointer ${
                  selectedServant 
                    ? 'bg-rose-500 hover:bg-rose-600 text-white active:scale-95' 
                    : 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                }`}
              >
                <span>{currentLang === 'en' ? 'Pick Booking Time' : 'ቀጥል'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: Pick Date and Free Time Slot */}
        {step === 4 && selectedServant && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <div>
              <div className="text-center max-w-sm mx-auto mb-6">
                <span className="inline-flex py-1 px-3 bg-rose-100 text-rose-700 text-xs font-bold rounded-full mb-2">Step 4</span>
                <h4 className="text-lg font-extrabold text-rose-950 uppercase tracking-tight">
                  {currentLang === 'en' ? 'Schedule Booking Slot' : 'ቀንና ሰዓት ይምረጡ'}
                </h4>
                <p className="text-xs text-rose-800 mt-1">
                  {currentLang === 'en' 
                    ? `Showing daily schedules with ${selectedServant.name}.` 
                    : `ከባለሙያ ${selectedServant.nameAm} ጋር ያለውን የነፃ ሰዓት ይመልከቱ።`}
                </p>
              </div>

              {/* Day selection */}
              <div className="flex gap-2 max-w-xs mx-auto mb-6">
                {['2026-06-18', '2026-06-19', '2026-06-20'].map((dateString) => {
                  const isDateSelected = selectedDate === dateString;
                  const dayNum = dateString.split('-')[2];
                  return (
                    <button
                      key={dateString}
                      onClick={() => {
                        setSelectedDate(dateString);
                        setSelectedTime('');
                      }}
                      className={`flex-1 py-2 px-1.5 rounded-xl border text-center transition-all cursor-pointer ${
                        isDateSelected
                          ? 'border-rose-500 bg-rose-50/60 ring-1 ring-rose-500 text-rose-800 font-extrabold'
                          : 'border-rose-100 bg-white text-rose-900 hover:bg-rose-50/50'
                      }`}
                    >
                      <CalendarIcon className="w-4 h-4 mx-auto mb-1 text-rose-400" />
                      <span className="text-[10px] uppercase font-bold block">
                        {dateString === '2026-06-18' ? (currentLang === 'en' ? 'Today' : 'ዛሬ') : dateString === '2026-06-19' ? (currentLang === 'en' ? 'Tomorrow' : 'ነገ') : (currentLang === 'en' ? 'Saturday' : 'ቅዳሜ')}
                      </span>
                      <span className="text-xs font-mono font-black">{dayNum} June</span>
                    </button>
                  );
                })}
              </div>

              {/* Daily dynamic timetable schedule */}
              <div className="max-w-xl mx-auto">
                <span className="block text-xs font-bold text-rose-900 uppercase tracking-wider mb-2.5 text-left flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-rose-500" />
                  {currentLang === 'en' ? 'Choose Free Appointment Time' : 'ነፃ ሰዓታት ይምረጡ'}
                </span>
                
                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {TIMEOBJECTS.map((timeStr) => {
                    const isBooked = isTimeSlotBooked(timeStr, selectedServant.id, selectedDate);
                    const isPicked = selectedTime === timeStr;
                    
                    if (isBooked) {
                      return (
                        <div
                          key={timeStr}
                          className="py-2.5 px-1 bg-red-50 text-red-400 border border-red-100 text-[11px] font-bold rounded-lg cursor-not-allowed select-none text-center"
                          title="This slot is already booked"
                        >
                          <span className="block">{timeStr}</span>
                          <span className="text-[8px] opacity-75 uppercase tracking-tight">[{translations.slotBooked[currentLang]}]</span>
                        </div>
                      );
                    }

                    return (
                      <button
                        key={timeStr}
                        onClick={() => setSelectedTime(timeStr)}
                        className={`py-2.5 px-1 text-[11px] font-bold rounded-lg transition-all text-center cursor-pointer border ${
                          isPicked
                            ? 'bg-rose-500 text-white border-transparent shadow shadow-rose-400 font-extrabold'
                            : 'bg-green-50/50 text-green-700 hover:bg-green-50 border-green-100 hover:border-green-300'
                        }`}
                      >
                        <span className="block">{timeStr}</span>
                        <span className="text-[8px] opacity-75 uppercase tracking-tight">[{translations.slotFree[currentLang]}]</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Step Controls */}
            <div className="flex justify-between pt-4 border-t border-rose-100 mt-6 md:mt-2">
              <button
                onClick={handleBack}
                className="flex items-center gap-1.5 px-4.5 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-full text-xs font-bold transition-all cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>{currentLang === 'en' ? 'Back' : 'በኋላ'}</span>
              </button>
              <button
                onClick={handleNext}
                disabled={!selectedTime}
                className={`flex items-center gap-1.5 px-6 py-3 rounded-full text-sm font-semibold shadow-md active:scale-95 transition-all cursor-pointer ${
                  selectedTime 
                    ? 'bg-rose-500 hover:bg-rose-600 text-white' 
                    : 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                }`}
              >
                <span>{currentLang === 'en' ? 'Remote Mobile Pay' : 'ክፍያ ቀጥል'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 5: Remote Mobile Payment Simulation */}
        {step === 5 && selectedService && selectedServant && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              
              <div className="text-center max-w-sm mx-auto">
                <span className="inline-flex py-1 px-3 bg-rose-100 text-rose-700 text-xs font-bold rounded-full mb-2">Step 5</span>
                <h4 className="text-lg font-extrabold text-rose-950 uppercase tracking-tight">
                  {translations.payTitle[currentLang]}
                </h4>
                <p className="text-xs text-rose-800 mt-1">
                  {translations.paySubtitle[currentLang]}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Receipt Card */}
                <div className="p-4 rounded-2xl bg-rose-50/50 border border-rose-100/70 text-left md:col-span-1 space-y-3">
                  <h5 className="text-xs font-bold text-rose-900 uppercase tracking-wider border-b border-rose-100 pb-1.5">
                    {currentLang === 'en' ? 'Cost Breakdown' : 'ዋጋ ዝርዝር'}
                  </h5>
                  
                  <div className="text-xs space-y-1.5 text-rose-950 font-medium">
                    <div className="flex justify-between">
                      <span>Base Treatment:</span>
                      <span className="font-mono">{selectedService.basePrice} ETB</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Service Tier:</span>
                      <span className="text-rose-600 font-bold">{selectedTier}</span>
                    </div>
                    {selectedTier !== 'Normal' && (
                      <div className="flex justify-between text-[10px] text-rose-700 bg-rose-100 px-1.5 py-0.5 rounded">
                        <span>Tier Upgrade:</span>
                        <span className="font-mono">+{selectedTier === 'VIP' ? '50%' : '100%'}</span>
                      </div>
                    )}
                    <div className="flex justify-between border-t border-rose-200 pt-2 text-sm font-black text-rose-900">
                      <span>{translations.payAmountToPay[currentLang]}:</span>
                      <span className="font-mono text-rose-600">{calculatePrice(selectedService.basePrice, selectedTier)} ETB</span>
                    </div>
                  </div>

                  <div className="border-t border-rose-200/50 pt-2 space-y-1 text-[10px] text-rose-800 font-medium">
                    <p>💅 <strong>Treatment:</strong> {currentLang === 'en' ? selectedService.nameEn : selectedService.nameAm}</p>
                    <p>👩‍🎤 <strong>Stylist:</strong> {currentLang === 'en' ? selectedServant.name : selectedServant.nameAm}</p>
                    <p>📅 <strong>Schedule:</strong> {selectedDate} @ {selectedTime}</p>
                  </div>
                </div>

                {/* Info and Wallet choice */}
                <div className="md:col-span-2 space-y-4 text-left">
                  {/* Guest details if not logged in / details update */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                        {currentLang === 'en' ? 'Your Name' : 'የእርስዎ ስም'} <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="e.g. Hermela"
                        className="block w-full px-3 py-2 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-white animate-pulse"
                        style={{ animationDuration: '3s' }}
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-rose-900 uppercase tracking-wider mb-1">
                        {currentLang === 'en' ? 'Your Phone' : 'የስልክ ቁጥር'} <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="tel"
                        value={customerPhone}
                        onChange={(e) => setCustomerPhone(e.target.value)}
                        placeholder="e.g. 0911223344"
                        className="block w-full px-3 py-2 border border-rose-200 rounded-xl text-neutral-800 placeholder-neutral-400 focus:outline-none focus:ring-1 focus:ring-rose-500 text-xs bg-white animate-pulse"
                        style={{ animationDuration: '3s' }}
                        required
                      />
                    </div>
                  </div>

                  {/* Payment Methods Options */}
                  <div className="space-y-2">
                    <label className="block text-[11px] font-bold text-rose-900 uppercase tracking-wider">
                      {currentLang === 'en' ? 'Select Preferred Channel' : 'የክፍያ አማራጭ ይምረጡ'} <span className="text-red-500">*</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {/* Telebirr */}
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('Telebirr')}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentProvider === 'Telebirr'
                            ? 'border-rose-500 bg-rose-50 text-rose-900 ring-2 ring-rose-400 font-bold'
                            : 'border-rose-100 bg-white text-neutral-600 hover:bg-rose-50/50'
                        }`}
                      >
                        <Wallet className="w-4 h-4 text-rose-500" />
                        <span className="text-[10px] block font-bold leading-tight">Telebirr / ቴሌብር</span>
                      </button>

                      {/* CBE */}
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('CBE')}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentProvider === 'CBE'
                            ? 'border-purple-600 bg-purple-50 text-purple-900 ring-2 ring-purple-400 font-bold'
                            : 'border-rose-100 bg-white text-neutral-600 hover:bg-rose-50/50'
                        }`}
                      >
                        <CreditCard className="w-4 h-4 text-purple-600" />
                        <span className="text-[10px] block font-bold leading-tight">CBE / ንግድ ባንክ</span>
                      </button>

                      {/* Dashen */}
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('Dashen')}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentProvider === 'Dashen'
                            ? 'border-amber-600 bg-amber-50 text-amber-900 ring-2 ring-amber-400 font-bold'
                            : 'border-rose-100 bg-white text-neutral-600 hover:bg-rose-50/50'
                        }`}
                      >
                        <Clock className="w-4 h-4 text-amber-500" />
                        <span className="text-[10px] block font-bold leading-tight font-sans">Dashen / ዳሽን</span>
                      </button>

                      {/* Abyssinia */}
                      <button
                        type="button"
                        onClick={() => setPaymentProvider('Abyssinia')}
                        className={`p-2 rounded-xl border text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-1 ${
                          paymentProvider === 'Abyssinia'
                            ? 'border-red-600 bg-red-50 text-red-900 ring-2 ring-red-400 font-bold'
                            : 'border-rose-100 bg-white text-neutral-600 hover:bg-rose-50/50'
                        }`}
                      >
                        <Sparkles className="w-4 h-4 text-red-600 animate-pulse" />
                        <span className="text-[10px] block font-bold leading-tight">Abyssinia / አቢሲኒያ</span>
                      </button>
                    </div>
                  </div>

                  {/* Read-Only Account copy controller */}
                  {(() => {
                    const activeAccount = bankAccounts[paymentProvider];
                    return (
                      <div className="p-3.5 bg-rose-50/40 rounded-2xl border border-rose-100 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="text-[9px] uppercase font-bold text-rose-500 block leading-none mb-0.5">Brand Provider</span>
                            <h5 className="text-[11px] font-black text-rose-950">
                              {currentLang === 'en' ? activeAccount.nameEn : activeAccount.nameAm}
                            </h5>
                          </div>
                          {copied ? (
                            <span className="text-[9px] bg-green-100 text-green-700 px-2 py-0.5 rounded font-bold animate-pulse flex items-center gap-0.5">
                              <Check className="w-3 h-3 text-green-700 stroke-[3]" />
                              {currentLang === 'en' ? 'Copied' : 'ኮፒ ተደርጓል'}
                            </span>
                          ) : (
                            <span className="text-[9px] text-rose-500 font-semibold italic">
                              {currentLang === 'en' ? 'Copiable details' : 'ቁጥሩን ኮፒ ማድረግ ይችላሉ'}
                            </span>
                          )}
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-left border-t border-b border-rose-100/50 py-2">
                          <div>
                            <span className="text-[9px] uppercase font-bold text-rose-500 block leading-none mb-0.5">Holder Name / ስም</span>
                            <p className="text-xs font-bold text-rose-950">
                              {currentLang === 'en' ? activeAccount.holderEn : activeAccount.holderAm}
                            </p>
                          </div>
                          <div>
                            <span className="text-[9px] uppercase font-bold text-rose-500 block leading-none mb-0.5">
                              {paymentProvider === 'Telebirr' 
                                ? (currentLang === 'en' ? 'Telebirr No.' : 'የቴሌብር ስልክ ቁጥር')
                                : (currentLang === 'en' ? 'Account No.' : 'የሂሳብ ቁጥር')
                              }
                            </span>
                            <p className="text-xs font-black text-rose-900 font-mono tracking-wider">
                              {activeAccount.number}
                            </p>
                          </div>
                        </div>

                        {/* Clipboard button overlay */}
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            readOnly
                            value={activeAccount.number}
                            className="bg-white border border-rose-200 rounded-xl px-3 py-1.5 text-xs font-mono font-bold text-rose-950 w-full focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={() => handleCopy(activeAccount.number)}
                            className="px-3.5 py-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shrink-0"
                          >
                            <span>{currentLang === 'en' ? 'Copy' : 'ኮፒ አድርግ'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Screenshot upload container */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] font-bold text-rose-900 uppercase tracking-wider">
                      {currentLang === 'en' ? 'Upload Payment Receipt Screenshot' : 'ክፍያ የተፈፀመበትን Screenshot (ደረሰኝ) የሚልኩበት አማራጭ'} <span className="text-red-500">*</span>
                    </label>
                    <div 
                      className="border-2 border-dashed border-rose-200 hover:border-rose-400 rounded-2xl p-4 transition-all text-center relative bg-rose-50/10 flex flex-col items-center justify-center cursor-pointer"
                      onClick={() => document.getElementById('screenshot-file-input')?.click()}
                      onDragOver={(e) => {
                        e.preventDefault();
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                          processUploadedFile(e.dataTransfer.files[0]);
                        }
                      }}
                    >
                      <input
                        id="screenshot-file-input"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            processUploadedFile(e.target.files[0]);
                          }
                        }}
                      />

                      {screenshotBase64 ? (
                        <div className="space-y-2">
                          <img 
                            src={screenshotBase64} 
                            alt="Payment Receipt Preview" 
                            className="mx-auto h-20 max-h-20 object-contain rounded-lg border border-rose-200 shadow-sm"
                          />
                          <p className="text-[10px] text-green-700 font-bold max-w-[200px] truncate mx-auto">
                            ✓ {screenshotName || 'screenshot.png'}
                          </p>
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setScreenshotBase64('');
                              setScreenshotName('');
                            }}
                            className="text-[9px] text-red-500 font-bold hover:underline"
                          >
                            {currentLang === 'en' ? 'Remove Image' : 'አስወግድ'}
                          </button>
                        </div>
                      ) : (
                        <div className="space-y-1 py-1">
                          <div className="text-xl">📸</div>
                          <p className="text-[11px] font-bold text-rose-950">
                            {currentLang === 'en' ? 'Drag screenshot here or click to browse' : 'ስክሪንሾት እዚህ ይጎትቱ ወይም እዚህ ይጫኑ'}
                          </p>
                          <p className="text-[9px] text-rose-600">
                            PNG, JPG, JPEG (Max 5MB)
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Processing Loader or Submit action */}
              {isProcessing ? (
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-center justify-center gap-3">
                  <Loader2 className="w-5 h-5 text-rose-600 animate-spin" />
                  <span className="text-xs font-bold text-rose-800">{translations.generatingQueue[currentLang]}</span>
                </div>
              ) : (
                <div className="flex justify-between pt-4 border-t border-rose-100 mt-6 md:mt-2">
                  <button
                    type="button"
                    onClick={handleBack}
                    className="flex items-center gap-1.5 px-4.5 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-full text-xs font-bold transition-all cursor-pointer"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    <span>{currentLang === 'en' ? 'Back' : 'በኋላ'}</span>
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white rounded-full text-sm font-semibold shadow-md active:scale-95 transition-all cursor-pointer"
                  >
                    <Check className="w-4 h-4" />
                    <span>{translations.btnConfirmPay[currentLang]}</span>
                  </button>
                </div>
              )}
            </form>
          </div>
        )}

        {/* STEP 6: Booking Confirmation Ticket (Receipt Voucher) */}
        {step === 6 && completedBooking && selectedService && selectedServant && (
          <div className="space-y-6 flex-1 flex flex-col justify-between">
            <div className="text-center max-w-md mx-auto space-y-4">
              
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600 animate-scale-up">
                <Smile className="w-6 h-6 stroke-[2.5]" />
              </div>
              
              <h4 className="text-lg font-black text-green-700 uppercase tracking-tight">
                {translations.paymentSuccess[currentLang]}
              </h4>
              
              {/* TICKET DETAILS OUTWARD GRID */}
              <div className="p-6 bg-white border border-rose-200 rounded-3xl relative overflow-hidden text-left shadow-lg">
                {/* Visual Tickets aesthetics (Circles left/right) */}
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-4 h-8 bg-white border border-rose-200 rounded-r-full -ml-[1px]"></div>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-8 bg-white border border-rose-200 rounded-l-full -mr-[1px]"></div>
                
                <div className="flex items-center justify-between border-b border-rose-100 pb-3 mb-4">
                  <div className="flex items-center gap-1 bg-rose-100 text-rose-700 font-extrabold text-[10px] px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                    <Crown className="w-3 h-3 text-rose-600" />
                    <span>{completedBooking.tier} {currentLang === 'en' ? 'Pass' : 'ማለፊያ'}</span>
                  </div>
                  <span className="text-[10px] text-rose-500 font-bold font-mono">
                    {translations.ticketCode[currentLang]}: <strong className="text-rose-900">{completedBooking.id}</strong>
                  </span>
                </div>

                <div className="space-y-2.5 text-xs text-rose-950 font-medium pb-4 border-b border-rose-100 border-dashed">
                  <div className="flex justify-between">
                    <span className="opacity-80">Guest Client:</span>
                    <strong className="text-rose-900 font-bold">{completedBooking.customerName}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-80">{translations.ticketStylist[currentLang]}:</span>
                    <strong className="text-rose-900 font-bold">{currentLang === 'en' ? selectedServant.name : selectedServant.nameAm}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-80">Treatment Type:</span>
                    <strong className="text-rose-900 font-bold">{currentLang === 'en' ? selectedService.nameEn : selectedService.nameAm}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-80">{translations.ticketTime[currentLang]}:</span>
                    <strong className="text-rose-900 font-bold font-mono">{completedBooking.date} @ {completedBooking.timeSlot}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="opacity-80">Payment Wallet:</span>
                    <strong className="text-rose-900 font-mono text-[10px] bg-rose-100/50 px-2 py-0.5 rounded">{completedBooking.paymentMethod}</strong>
                  </div>
                  <div className="flex justify-between text-sm pt-1">
                    <span className="font-extrabold text-rose-900">{translations.ticketPricePaid[currentLang]}:</span>
                    <strong className="font-mono text-rose-600 text-base font-black">{completedBooking.paidAmount} ETB</strong>
                  </div>
                </div>

                {/* Queue Display Panel */}
                <div className="pt-4 text-center">
                  <div className="bg-white/80 border border-rose-100 rounded-2xl p-3 inline-block mx-auto min-w-[200px]">
                    <span className="text-[10px] font-bold text-rose-500 uppercase tracking-widest block">
                      {translations.ticketQueue[currentLang]}
                    </span>
                    <strong className="text-3xl font-black text-rose-950 tracking-tight font-mono block my-1">
                      #{completedBooking.queueNo}
                    </strong>
                    <span className="text-[10px] text-rose-700 bg-rose-50 px-2 py-0.5 rounded-full font-bold">
                      {translations.estimatedWait[currentLang]}: ~{completedBooking.queueNo % 2 === 0 ? 35 : 15} {translations.mins[currentLang]}
                    </span>
                  </div>
                </div>

              </div>

              <p className="text-xs text-rose-500 italic max-w-xs mx-auto">
                {translations.ticketSubtitle[currentLang]}
              </p>
            </div>

            {/* Confirmation actions */}
            <div className="flex gap-2 pt-4 border-t border-rose-100 mt-6 md:mt-2">
              <button
                onClick={() => {
                  window.print();
                }}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 border border-rose-200 text-rose-700 hover:bg-rose-50 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                <Ticket className="w-4 h-4" />
                <span>{translations.printTicket[currentLang]}</span>
              </button>
              <button
                onClick={resetWizard}
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-md active:scale-95 transition-all cursor-pointer"
              >
                <span>{currentLang === 'en' ? 'New Booking' : 'አዲስ ቀጠሮ'}</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
