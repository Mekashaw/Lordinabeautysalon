import React from 'react';
import { translations } from '../translations';
import { Sparkles, Languages, LogIn, LogOut, ShieldAlert } from 'lucide-react';

const logo = "/src/assets/images/lordina_salon_logo_1781786387886.jpg";

interface HeaderProps {
  currentLang: 'en' | 'am';
  setCurrentLang: (lang: 'en' | 'am') => void;
  isLoggedIn: boolean;
  username: string | null;
  isAdmin: boolean;
  onOpenLogin: () => void;
  onLogout: () => void;
}

export default function Header({
  currentLang,
  setCurrentLang,
  isLoggedIn,
  username,
  isAdmin,
  onOpenLogin,
  onLogout
}: HeaderProps) {
  const switchLanguage = () => {
    setCurrentLang(currentLang === 'en' ? 'am' : 'en');
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-rose-100 shadow-sm px-4 py-3 sm:px-6">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* LOGO AND BRANDING - Guaranteed on a single line */}
        <div className="flex items-center gap-3 select-none flex-shrink-0">
          <div className="relative w-12 h-12 rounded-full overflow-hidden border-2 border-rose-400 shadow-md">
            <img
              src={logo}
              alt="Lordina Salon Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
              onError={(e) => {
                // If there's any load issue, fallback to beautiful stock image of beautiful dark-skinned woman
                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&q=80&w=150';
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-rose-500/20 to-transparent"></div>
          </div>
          
          <div className="flex flex-col">
            <h1 className="text-xl sm:text-2xl font-black text-rose-600 tracking-tight whitespace-nowrap">
              {translations.brandName[currentLang]}
            </h1>
            <span className="text-[10px] sm:text-xs text-rose-500 font-medium tracking-wide hidden sm:block whitespace-nowrap">
              {translations.tagline[currentLang]}
            </span>
          </div>
        </div>

        {/* ACTIONS / CONTROLS - Vertically stacked (top / bottom) to save space with login badge visible */}
        <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
          {/* TOP element: Compact English / Amharic Toggle */}
          <div className="flex items-center bg-rose-50/50 p-0.5 rounded-full border border-rose-100 text-xs gap-0.5 select-none shrink-0 shadow-sm">
            <button
              onClick={() => setCurrentLang('am')}
              className={`px-2 py-0.5 rounded-full font-bold cursor-pointer transition-all duration-200 text-[10px] sm:text-xs ${
                currentLang === 'am'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-rose-700 hover:bg-rose-100'
              }`}
              title="Amharic / አማርኛ"
            >
              አማ
            </button>
            <button
              onClick={() => setCurrentLang('en')}
              className={`px-2 py-0.5 rounded-full font-bold cursor-pointer transition-all duration-200 text-[10px] sm:text-xs ${
                currentLang === 'en'
                  ? 'bg-rose-500 text-white shadow-sm'
                  : 'text-rose-700 hover:bg-rose-100'
              }`}
              title="English"
            >
              EN
            </button>
          </div>

          {/* BOTTOM element: User welcome card and Login/Logout Action */}
          <div className="flex items-center gap-1.5 shrink-0">
            {isLoggedIn && (
              <div className="hidden md:flex items-center gap-1 px-2.5 py-0.5 bg-rose-50 text-rose-700 border border-rose-100 rounded-full text-[10px] font-semibold">
                <Sparkles className="w-2.5 h-2.5 text-rose-500 animate-pulse" />
                <span>
                  {translations.welcomeBack[currentLang]}, <strong className="text-rose-800">{username}</strong>
                  {isAdmin && <span className="ml-1 text-[8px] px-1 bg-rose-200 text-rose-800 rounded font-bold">Admin</span>}
                </span>
              </div>
            )}

            {/* Login/Logout Button */}
            {isLoggedIn ? (
              <button
                onClick={onLogout}
                className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 shadow-sm transition-all duration-200 cursor-pointer"
                id="header-logout-btn"
              >
                <LogOut className="w-3 h-3" />
                <span>{translations.logoutBtn[currentLang]}</span>
              </button>
            ) : (
              <button
                onClick={onOpenLogin}
                className="flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold text-white bg-rose-500 hover:bg-rose-600 shadow-sm transition-all duration-200 cursor-pointer"
                id="header-login-btn"
              >
                <LogIn className="w-3 h-3" />
                <span>{translations.loginBtn[currentLang]}</span>
              </button>
            )}
          </div>
        </div>

      </div>
    </header>
  );
}
